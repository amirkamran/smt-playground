/*!
This is global definition for all main files of the program set
*/
