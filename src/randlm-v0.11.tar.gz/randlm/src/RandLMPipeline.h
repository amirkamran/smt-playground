// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef RANDLM_PIPELINE_H
#define RANDLM_PIPELINE_H

#include "RandLMPreproc.h"
#include "RandLMVocab.h"
#include "RandLMStats.h"

namespace randlm {
  
  // RandLMPipeline manages input, conversion and output of all 
  // data formats prior to construction of RandLMStruct or RandLM.
  
  // It owns the Vocab object that is used to map between Words and WordIDs.
  // Data passed down the pipeline is wrapped by InputData (see RandLMPreproc.h).
  // RandLMPipelineTool wraps Pipeline for use in command line tools.
  
  class Pipeline {  
  public:
    Pipeline(InputData* input_data, Vocab* vocab, Stats* stats) {
      input_data_ = input_data;
      vocab_ = vocab;
      stats_ = stats;
      converted_data_ = NULL;
    }
    ~Pipeline() { 
      delete input_data_; 
      delete converted_data_; 
      delete vocab_;
      delete stats_;
    }
    // convert and format data
    bool preprocess(FileType output_type, Format output_format);
    bool getOutput(InputData*& output_data, Vocab*& vocab, Stats*& stats);
    FileType getInputType() { return input_data_->getInputType(); }
    Format getInputFormat() { return input_data_->getFormat(); }
  private:
    bool validOutputFileType(FileType output_type);
    InputData* input_data_;
    Vocab* vocab_;
    Stats* stats_;
    InputData* converted_data_;
  };
}

#endif // RANDLM_PIPELINE
