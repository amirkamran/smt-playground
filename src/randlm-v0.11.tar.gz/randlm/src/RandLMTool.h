// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_TOOL_H
#define INC_RANDLM_TOOL_H

#include <set>
#include <map>
#include "RandLMPreproc.h"
#include "RandLMParams.h"

namespace randlm {
  
  // abstract class providing interface for constraints and 
  // dependencies on parameters specific to a given cmd line tool.
  
  // subclasses can use the following methods to set their 
  // requirements in an setRequirements() implementation
  
  // setRequire(parameter name1)
  //  require that 'name1' is set.
  //
  // setDisallow(parameter name1)
  //  require that 'name1' is never set.
  //
  // setRequireOne(ParamSet params)
  //  require at least one of 'params' is set
  //
  // These methods optionally take a second parameter name to introduce a 
  // conditional dependency: 
  //  e.g., setRequire(A, B); makes A a required parameter if B is set
  //

  class RandLMTool {
    
  public:
    RandLMTool(RandLMParams* params) {
      assert(params != NULL);
      params_ = params;
    }
    virtual ~RandLMTool() {} // nothing to delete we don't own params
  protected:
    virtual bool setRequirements() = 0; 
    virtual bool setDefaultValues() = 0;
    bool checkParams(const std::string & caller); 
    bool setRequire(const std::string & name, const std::string & cond_name = "");
    bool setRequireOne(const ParamSet & paramset, const std::string & cond_name = "");
    bool setDisallow(const std::string & name, const std::string & cond_name = "");
    bool setDisallowValue(const std::string & name, const std::string & value);
    bool setRequireValue(const std::string & name, const std::string & value);
    bool setDefault(const std::string & name, const std::string & value);
    bool setDefault(const std::string & name, const std::string & value,
		    const std::string & cond_name);
    bool setDefault(const std::string & name, const std::string & value,
		    const std::string & cond_name, const std::string & cond_value);

    RandLMParams* params_;  // not owned
    bool printParamSet(const ParamSet & paramSet) const;
  private:
    // parameters that must be defined
    ParamSet required_;
    // at least one of each group should be set
    std::set<ParamSet> one_required_;
    // conditionally required parameters
    std::map<std::string, ParamSet> cond_required_;
    // conditionally required at least one of parameters
    std::map<std::string, ParamSet> cond_one_required_;
    // parameters that must not be defined
    ParamSet disallowed_; 
    // conditionally disallowed parameters
    std::map<std::string, ParamSet> cond_disallowed_;
    // disallowed values for specific parameters
    std::map<std::string, ValueSet> disallowed_values_;
    // require values for specific parameters
    std::map<std::string, std::string> required_values_;
  };  
}

#endif  // ends INC_RANDLM_TOOL_H
