// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_COUNT_MIN_SKETCH_H
#define INC_COUNT_MIN_SKETCH_H

#include "RandLMStruct.h"
#include "RandLMHash.h"
#include "RandLMFilter.h"

namespace randlm {
  // CountMinSketch is described in (Cormode and Muthukrishnan 2004).
  // The implementation here is only for 'point queries'.
  // It consists of a set of arrays of counters each associated with
  // one hash function (multiple such sets if ngrams have distinct 
  // error rates).
  class CountMinSketch : public OnlineRandLMStruct {
  public:
    CountMinSketch(RandLMInfo* info) : RandLMStruct(info),
      OnlineRandLMStruct(info) {
      assert(initMembers());
    }
    CountMinSketch(RandLMInfo* info, RandLMFile* fin) 
      : RandLMStruct(info, fin), OnlineRandLMStruct(info, fin) {
      assert(initMembers());
      assert(load(fin));
    }
    // client functions
    bool insert(const WordID* ngram, int len, int event_idx, int code);
    bool query(const WordID* ngram, int len, int event_idx, int* code, int max);
    bool query(const WordID word, int start, int end, int event_idx, int* code, int max);
    bool count(const WordID* ngram, int len);
    bool count(const WordID word, int start, int end);
    bool optimise(float working_mem);
    bool assignCountMapping(LogQuantiser* log_quantiser);
    bool save(RandLMFile* fout);
    uint64_t getSize() { return 0; }
  protected:
    bool initMembers();
    bool load(RandLMFile* fin);
    CountingFilter<uint32_t>*** counter_arrays_;  // multiple arrays possibly distinct per ngram order
    UniversalHash<uint32_t>* hashes_;  // one hash function per array
  };
}

#endif  // INC_COUNT_MIN_SKETCH_H
