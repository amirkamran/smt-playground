// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_FILE_H
#define INC_RANDLM_FILE_H

#include <iostream>
#include <fstream>
#include <cstdio>
#include <sys/stat.h>
#include <string>
#include <cassert>
#include "fdstream.h"

namespace randlm {

  typedef std::string FileExtension;
  
  class RandLMFile: public std::fstream {
  public:
    // descriptors for stdin and stdout
    static const std::string kStdInDescriptor;  // file name for std::cin
    static const std::string kStdOutDescriptor;  // file name for std::cout
    // compression commands
    static const std::string kCatCommand;  // i.e. no compression
    static const std::string kGzipCommand;  // gzip -f
    static const std::string kGunzipCommand;  // gunzip -f
    static const std::string kBzip2Command;  // bzip2 -f
    static const std::string kBunzip2Command;  // bunzip2 -f

    // open file or wrap stdin or stdout
    RandLMFile(const std::string & path,
	       std::ios_base::openmode flags = std::ios::in,
	       bool checkExists = true);
    ~RandLMFile();
    // file utilities 
    static bool getCompressionCmds(const std::string & filepath,
				   std::string & compressionCmd,
				   std::string & decompressionCmd,
				   std::string & compressionSuffix);
    
    // data accessors
    std::string getPath() { return path_; }
    std::ios_base::openmode getFlags() { return flags_; }
    bool isStdIn() { return path_ == RandLMFile::kStdInDescriptor; }
    bool isStdOut() { return path_ == RandLMFile::kStdOutDescriptor; }
    bool reset();
  protected:
    static const FileExtension kGzipped;
    static const FileExtension kBzipped2;
    bool fileExists();
    bool setStreamBuffer(bool checkExists);
    bool isCompressedFile(std::string & cmd);
    fdstreambuf* openCompressedFile(const char* cmd);
    std::string path_; // file path 
    std::ios_base::openmode flags_;  // open flags
    std::streambuf* buffer_;  // buffer to either gzipped or standard data
    std::FILE* fp_;  //file pointer to handle pipe data
  };

}  // ends namespace

#endif //INC_RAND_LM_HEADER_H
