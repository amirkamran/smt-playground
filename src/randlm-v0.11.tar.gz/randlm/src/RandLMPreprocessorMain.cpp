#include "RandLMPreprocessor.h"
using namespace randlm;

// Tool for preprocessing data prior to constructing a randlm

int main(int argc, char ** argv) {
  // init static data
  RandLMParams::init();
  // read parameters 
  RandLMParams params(argc, argv);
  // class that handles data preprocessing
  RandLMPreprocessor preprocessor(&params);
  // preprocess the input data and save
  assert(preprocessor.preprocess());
  return 0;
}
