// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "LossyDict.h"

namespace randlm {

  bool LossyDict::insert(const WordID* ngram, int len, int event_idx, int code) {
    return true;
  }

  bool LossyDict::query(const WordID* ngram, int len, int event_idx, int* code, int max) {
    return true;
  }

  bool LossyDict::query(const WordID word, int start, int end, int event_idx, int* code, int max) {
    return true;
  }

  bool LossyDict::optimise(float working_mem) {
    // table size: determined by false neg rate.
    // really should sample hash functions until false neg rate is achieved 
    // but that would be to slow but need analytic formulae.
    // fingerprint size: determined by false pos rate.

    return false;
  }
 
  bool LossyDict::initMembers() {
    // set up any member data here that doesn't depend on knowing input data
    objects_ = new uint64_t[order_specific_ ? order_ : 1];
    for (int i = 0; i < (order_specific_ ? order_ : 1); ++i)
      objects_[i] = 0;
    return false;
  }
  
  bool LossyDict::setCodeCounts(CodeCounts codes, uint64_t total, int event_idx, int order) {
    // called once for each event_idx (and for each order if order specific error rate)
    objects_[order_specific_ ? order - 1 : 0] += total;
    return true;
  }

  bool LossyDict::load(RandLMFile* fin) {
    // load data in same order as save below
    return true;
  }

  bool LossyDict::save(RandLMFile* fout) {
    // call parent first
    assert(fout != NULL && StaticRandLMStruct::save(fout));
    return true;
  }
  
}

