// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef RANDLM_QUERY_H
#define RANDLM_QUERY_H

#include "RandLMParams.h"
#include "RandLMTool.h"
#include "RandLM.h"

namespace randlm {
  
  // RandLMQuery is a command line tool for querying
  // a previously created RandLM.
  
  // It requires a RandLM to be specified and processes queries
  // input in various formats.
  
  class RandLMQuery : public RandLMTool {
  public:
    const static std::string kQuery;
    RandLMQuery(RandLMParams* params) : RandLMTool(params) {
      randlm_ = NULL;
      test_data_ = NULL;
      order_ = 0;
      corpus_data_ = false;
      getcounts_ = false;
      // Check parameters and then setup input data
      assert(checkParams(kQuery));
      assert(load());
    }
    ~RandLMQuery() { 
      delete randlm_; 
      delete test_data_;
    }
    bool query(); // reads ngrams from path or stdin and writes scores them to stdout
  private:
    bool load();
    bool setRequirements();
    bool setDefaultValues();
    RandLM* randlm_;
    CountRandLM* count_randlm_;
    TestCorpus* test_data_;
    int order_;
    bool corpus_data_;
    bool getcounts_;
  };
}

#endif // RANDLM_QUERY

