// Copyright 2008 Abby Levenberg, David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_LOSSY_DICT_H
#define INC_LOSSY_DICT_H

#include "RandLMHash.h"
#include "RandLMFilter.h"
#include "RandLMStruct.h"

namespace randlm {
  // The LossyDict is described in (Pagh and Rodler 2001).
  class LossyDict : public StaticRandLMStruct {
  public:
    // constructore used for building lossy dict from scratch
    LossyDict(RandLMInfo* info) : StaticRandLMStruct(info) {
      // any constraints? if so check info here
      assert(initMembers());
    }
    // used for loading from file
    LossyDict(RandLMInfo* info, RandLMFile* fin) 
      : StaticRandLMStruct(info, fin) {
      assert(initMembers());
      assert(load(fin));
    }
    // client functions
    bool insert(const WordID* ngram, int len, int event_idx, int code);
    bool query(const WordID* ngram, int len, int event_idx, int* code, int max);
    bool query(const WordID word, int start, int end, int event_idx, int* code, int max);
    // called by RandLM to specify what counts to expect
    bool setCodeCounts(CodeCounts counts, uint64_t total, int event_idx, int order = 0);  
    // called by RandLM to optimise structure i.e. setup table sizes and hash functions
    bool optimise(float working_mem);  
    // i/o functions need to read and write data in same order
    bool save(RandLMFile* file);  
    uint64_t getSize() { return m_; }
  private:
    bool initMembers();  // just set up empty (unoptimised member data if any)
    bool load(RandLMFile* file);  
    Filter<uint32_t>*** tables_;  // two or more tables possibly indexed by ngram order 
    UniversalHash<uint32_t>*** hashes_;  // one hash per table, per event type and possibly per ngram order
    UniversalHash<uint32_t>*** fingerprints_; // one per table, per even type and possibly per ngram order
    uint64_t m_; // total memory
    uint64_t* objects_; 
  };
}

#endif // INC_LOSSY_DICT_H
