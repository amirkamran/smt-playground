// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMBuilder.h"

namespace randlm {

  const std::string RandLMBuilder::kBuilder = "Builder";    

  class NgramFile;

  bool RandLMBuilder::getRandLM(RandLM*& randlm) {
    // pass ownership of randlm to caller
    assert(randlm_ != NULL);
    randlm = randlm_;
    randlm_ = NULL;  // relinquish
    return true;
  }

  bool RandLMBuilder::setRequirements() {
    // (file related parameters are dealt with in parent class)
    // set up required parameters
    setRequire("order");
    setRequire("struct");
    setRequire("values");
    //setRequire("smoothing");
    // one of these two is required
    ParamSet errorOrSizeParams;
    errorOrSizeParams.insert("memory");
    errorOrSizeParams.insert("falsepos");
    setRequireOne(errorOrSizeParams);
    // disallow formatting parameters if output-type RandLM
    // since in that case we determine formatting on the basis of 
    // RandLM's input requirements
    setDisallow("output-integerised");
    setDisallow("output-normalised");
    setDisallow("output-reversed-ngrams");
    setDisallow("output-sorted-by-ngram");
    setDisallow("output-sorted-by-value");
    setRequireValue("output-type", RandLM::kRandLMFileType);
    return true;
  }

  bool RandLMBuilder::setDefaultValues() {
    // these cannot (currently) override default settings of parent
    // but no defaults will override any user specified parameters.
    setDefault("falsepos", "8");  // = 1/256 < 0.005
    setDefault("falseneg", "0");
    setDefault("misassign", "1");
    setDefault("count-cut-off", "1");
    setDefault("memory","0");  //
    setDefault("maxcount","35");  // large enough ? 
    setDefault("output-type", RandLM::kRandLMFileType); 
    setDefault("struct", RandLMStruct::kBloomierFilter);  // not sure about this ? 
    //setDefault("smoothing", RandLM::kStupidBackoffSmoothing); 
    setDefault("smoothing-param", "0.4"); // apparently reasonable value
    return true;
  }

  bool RandLMBuilder::preprocess() {
    assert(info_ == NULL);
    // instantiate RandLMInfo object that holds LM configuration and error parameters etc.
    assert(setupInfo());
    // determine what preprocessing will be necessary given current input and info
    FileType targetFileType = InputData::kNullFileType;;
    Format targetFormat = InputData::kNullFormat;
    assert(RandLM::getInputRequirements(info_, pipeline_->getInputType(), pipeline_->getInputFormat(),
					&targetFileType, &targetFormat));
    // preprocess data into correct format (always require statistics)
    return pipeline_->preprocess(targetFileType, targetFormat);
  }
  
  bool RandLMBuilder::build() {
    // pipeline_ now contains formatted data, vocab and stats (if required)
    assert(info_ != NULL && randlm_ == NULL);  // info was set up in preprocess
    // get output of pipeline
    InputData* formatted_data;
    Vocab* vocab;
    Stats* stats;
    assert(pipeline_->getOutput(formatted_data, vocab, stats));
    // instantiate correct type of randlm (takes ownership of info_ and vocab
    randlm_ = RandLM::initRandLM(info_, vocab);
    assert(randlm_ != NULL);
    info_ = NULL;
    vocab = NULL;
    // build either online via corpus or from ngram file
    float working_mem = RandLMUtils::StringToFloat(params_->getParamValue("working-mem"));
    assert(randlm_->build(formatted_data, stats, working_mem));
    return randlm_->save(getStructPath());
  }

  bool RandLMBuilder::getConfiguration(StructCode* code, Smoothing* scheme, Estimator* estimator,
				       EventType* events) {
    std::cerr << "Derived parameters settings: " <<std::endl;
    // Determine user specified parameters for RandLM configuration (or guess reasonable ones)
    assert(RandLMStruct::getStructCode(params_->getParamValue("struct"), code));
    // Determine estimation scheme (batch, online, probabilistic)
    if (!RandLMStruct::getEstimatorCode(params_->getParamValue("estimator"), estimator)) {
      // Get default estimator for this struct and input data since none specified
      assert(RandLMStruct::getDefaultEstimator(*code, pipeline_->getInputType(), estimator));
      std::cerr << "\t" << "estimator" << "\t" << RandLMStruct::getEstimatorName(*estimator) << std::endl;
    }
    // Determine smoothing scheme used by model 
    if(!RandLM::getSmoothingCode(params_->getParamValue("smoothing"), scheme)) {
      assert(RandLM::getDefaultSmoothing(*code, pipeline_->getInputType(), *estimator, scheme));
      std::cerr << "\t" << "smoothing" << "\t" << RandLM::getSmoothingName(*scheme) << std::endl;
    }
    // determine the event type(s) this smoothing scheme requires
    assert(RandLM::getRequiredEventType(*scheme, events));
    // make sure everything got set reasonably
    return *code != RandLMStruct::kNullStructCode && *scheme != RandLM::kNullSmoothingCode 
      && *estimator != RandLMStruct::kNullEstimationCode && *events != RandLMInfo::kNullEvent;
  } 
  
  bool RandLMBuilder::setupInfo() {
    // Determine configuration
    StructCode code = RandLMStruct::kNullStructCode; // what randomised data structure to use
    Smoothing scheme = RandLM::kNullSmoothingCode;  // smoothing scheme 
    Estimator estimator = RandLMStruct::kNullEstimationCode;  // how to estimate/obtain the required statistics 
    EventType events = RandLMInfo::kNullEvent;  // types of frequency events stored in the model
    assert(getConfiguration(&code, &scheme, &estimator, &events));
    // construct RandLMInfo from command line parameters
    std::vector<std::string> false_pos_params, false_neg_params, misassign_params, fail_prob_params,
      max_count_params, values_params;
    int num_false_pos_params = params_->getVectorParamValues("falsepos", false_pos_params);
    int num_false_neg_params = params_->getVectorParamValues("falseneg", false_neg_params);
    int num_misassign_params = params_->getVectorParamValues("misassign", misassign_params);
    int num_fail_prob_params = params_->getVectorParamValues("failprob", fail_prob_params);
    // if any of the parameters are order_specific (i.e. one per ngram length then treat all as such)
    bool order_specific_errors =  num_false_pos_params > 1 || num_false_neg_params > 1
      || num_misassign_params > 1 || num_fail_prob_params > 1;
    // get order of model
    int order = RandLMUtils::StringToInt(params_->getParamValue("order"));
    // either have one param for all ngram lengths OR one/zero per length
    assert(num_false_pos_params == order || num_false_pos_params < 2);
    assert(num_false_neg_params == order || num_false_neg_params < 2);
    assert(num_misassign_params == order || num_misassign_params < 2);
    assert(num_fail_prob_params == order || num_fail_prob_params < 2);
    // get quantisation information (max count and range of values)
    float values = RandLMUtils::StringToFloat(params_->getParamValue("values"));
    float memory = RandLMUtils::StringToFloat(params_->getParamValue("memory"));
    float max_count = RandLMUtils::StringToFloat(params_->getParamValue("maxcount"));
    float smoothing_param = RandLMUtils::StringToFloat(params_->getParamValue("smoothing-param"));
    // set up RandLMInfo
    info_ = new RandLMInfo(order, code, events, values, memory, max_count, scheme, 
			   smoothing_param, estimator, order_specific_errors);
    // set up error rates
    for (int i = 0; i < num_false_pos_params; ++i)
      info_->setFalsePos(RandLMUtils::StringToFloat(false_pos_params[i]), i+1);
    for (int i = 0; i < num_false_neg_params; ++i)
      info_->setFalseNeg(RandLMUtils::StringToFloat(false_neg_params[i]), i+1);
    for (int i = 0; i < num_misassign_params; ++i)
      info_->setMisassign(RandLMUtils::StringToFloat(misassign_params[i]), i+1);
    for (int i = 0; i < num_fail_prob_params; ++i)
      info_->setFailProb(RandLMUtils::StringToFloat(fail_prob_params[i]), i+1);
    return true;
  }
  std::string RandLMBuilder::getStructPath() {
    // determine output path
    return params_->getParamValue("output-dir") + "/" + 
      params_->getParamValue("output-prefix") + "." + params_->getParamValue("struct");
  }
}
