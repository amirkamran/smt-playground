// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMPipeline.h"

namespace randlm {
  
  bool Pipeline::preprocess(FileType output_type, Format output_format) {
    std::cerr << "Pipeline converting data from " << input_data_->getInputType() << " to " 
	      << output_type << std::endl;
    // check that the conversion is possible
    assert(validOutputFileType(output_type));
    assert(converted_data_ == NULL);
    // perform conversion only if required
    if (output_type == input_data_->getInputType() &&
	(output_format & ~input_data_->getFormat()) == 0) {
      // no changes to data
      converted_data_ = input_data_;
      input_data_ = NULL;
    } else {     
      // convert to some normalised format
      NormalisedNgramFile* normalised_data;
      assert(input_data_->normalise(output_format, normalised_data)); 
      converted_data_ = normalised_data;
      delete input_data_;  // delete original data
      input_data_ = NULL;
    }
    assert(converted_data_ != NULL);
    // get statistics (estimate if necessary)
    assert(Stats::getStats(stats_, converted_data_));
    if (stats_->hasNgramStats())
      assert(stats_->save(converted_data_->getStatsPath()));
    if (stats_->hasTokenStats())
      assert(stats_->saveTokenStats(converted_data_->getWordCountPath()));
    // store vocab
    assert(vocab_->save(converted_data_->getVocabPath()));
    return true;
  }
  
  bool Pipeline::getOutput(InputData*& converted_data, Vocab*& vocab, Stats*& stats) {
    // pass ownership of converted data and vocab to caller
    if (converted_data_ != NULL) {
      converted_data = converted_data_;
      converted_data_ = NULL;
    } else {  // we didn't convert anything so just pass back input
      converted_data = input_data_;
      input_data_ = NULL;
    }
    assert(vocab_ != NULL && stats_ != NULL);
    // hand back vocab and stats
    vocab = vocab_;
    vocab_ = NULL;
    stats = stats_;
    stats_ = NULL;
    return true;
  }

  bool Pipeline::validOutputFileType(FileType output_type) {
    // determine whether output-type data 
    // can be generated from the current input-data
    assert(input_data_ != NULL);
    bool valid = false;
    // specify valid conversions between primitive data formats
    if (input_data_->isCorpusData())
      valid = (output_type == InputData::kCountFileType ||
	       output_type == InputData::kCorpusFileType);
    // can only convert arpa file to backoff model file
    else if (input_data_->isBackoffData())
      valid = output_type == InputData::kBackoffModelFileType;
    else if (input_data_->isCountData())
      valid = output_type == InputData::kCountFileType;
    return valid;
  }
}
