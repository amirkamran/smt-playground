// Copyright 2008 David Talbot, Abby Levenberg
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMPreproc.h"
#include "RandLMVocab.h"
#include "RandLMStats.h"
#include "RandLMParams.h"
#include <sstream>

namespace randlm {

  // class InputData
  const int InputData::kNormalisedBit;
  const int InputData::kIntegerisedBit;
  const int InputData::kSortedByNgramBit;
  const int InputData::kSortedByValueBit;
  const int InputData::kReversedNgramsBit;

  const Format InputData::kNullFormat;
  const Format InputData::kRawFormat;
  const Format InputData::kNormalisedFormat;
  const Format InputData::kIntegerisedFormat;
  const Format InputData::kSortedByNgramFormat;
  const Format InputData::kSortedByValueFormat;
  const Format InputData::kReversedNgramsFormat;
  
  const std::string InputData::kNullFileType = "__NULL__";  
  const std::string InputData::kNgramsFileType = "ngrams";  
  const std::string InputData::kCorpusFileType = "corpus";  
  const std::string InputData::kArpaFileType = "arpa";
  const std::string InputData::kCountFileType = "counts";
  const std::string InputData::kBackoffModelFileType = "backoff";

  const std::string InputData::kTokenFileSuffix = "tokens";
  const std::string InputData::kNormalisedFileSuffix = "norm";
  const std::string InputData::kReversedFileSuffix = "reversed";
  const std::string InputData::kIntegerisedFileSuffix = "ints";
  const std::string InputData::kCountFileSuffix = "counts";
  const std::string InputData::kBackoffModelFileSuffix = "backoff";
  const std::string InputData::kStatsFileSuffix = "stats";
  const std::string InputData::kWordCountFileSuffix = "wc";
  const std::string InputData::kVcbFileSuffix = "vcb";

  bool InputData::reset() {
    assert(source_ != NULL);
    line_num_ = 0;
    return source_->reset();
  }

  bool InputData::switchSource(std::string & newSourcePath) {
    assert(source_ != NULL);
    source_->close();
    delete source_;
    input_path_ = newSourcePath;
    source_ = new RandLMFile(input_path_, std::ios::in); 
    return true;
  }

  bool InputData::getWordCount(uint64_t* lines, uint64_t* tokens, uint64_t* bytes) {
    // count words in file
    std::cerr << "not doing wc!" << std::endl;
    *lines = 1;
    *tokens = 1;
    *bytes = 1;
    return true;  // for now
    
    std::string wc_output = getWordCountPath();
    std::string wcCmd = "cat " + input_path_ + " | " + decompress_cmd_ + " | wc > " + wc_output;
    std::cerr << wcCmd << std::endl;
    assert(system(wcCmd.c_str()) != 0);
    RandLMFile wcFile(wc_output);
    std::string line;
    getline(wcFile, line);
    std::istringstream counts(line.c_str());
    assert(counts >> *lines);
    assert(counts >> *tokens);
    assert(counts >> *bytes);
    return true;
  }

  std::string InputData::getOutputPath(const std::string & fileSuffix, Format outputFormat) {
    // determine correct path given formatting, filesuffix and compression suffix
    assert(fileSuffix.size() > 0);
    assert(!inconsistentSort(outputFormat));
    std::string path = output_dir_ + "/" + output_prefix_ + "." + fileSuffix;
    if (outputFormat & kSortedByNgramFormat)
      path += ".sorted";
    if (outputFormat & kSortedByValueFormat)
      path += ".sortedval";
    if (outputFormat & kReversedNgramsFormat)
      path += ".reversed";
    if (outputFormat & kIntegerisedFormat)
      path += ".ints";
    path += compression_suffix_;
    std::cerr << "output path = " << path << std::endl;
    return path;
  }

  bool InputData::readNgram(std::istringstream* entry, WordID* ngram, int* len,
			    Format format, int maxLen = RandLM::kMaxNgramOrder) {
    // read ngram from file taking formatting into account. 
    // return pointer to start of ngram.
    std::string token;
    *len = 0;
    // un-do 'reversing' of ngram if applied on disk
    int idx = (format & kReversedNgramsFormat) ? maxLen - 1 : 0;
    int incr = (format & kReversedNgramsFormat) ? -1 : +1; 
    while (*entry >> token && *len < maxLen) {
      // use vocab if not already 'integerised' 
      ngram[idx] = (format & kIntegerisedFormat) ? RandLMUtils::StringToUint32(token) 
	: vocab_->getWordID(token);
      idx += incr;
      ++(*len);
    }
    // copy back to start of 'ngram' if fewer tokens read
    if ( (format & kReversedNgramsFormat) && (*len < maxLen) )
      for (int i = 0; i < *len; ++i)
	ngram[i] = ngram[i + (maxLen - *len)];
    return *len > 0;
  }

  bool InputData::writeNgram(WordID* ngram, int len, RandLMFile* out, 
			     Format outputFormat) {
    // output ngram to file with appropriate formatting
    for (int i = 0; i < len; ++i) {
      if (outputFormat & kIntegerisedFormat)
	*out << ngram[(outputFormat & kReversedNgramsFormat) ? (len-1-i) : i];
      else
	*out << vocab_->getWord(ngram[(outputFormat & kReversedNgramsFormat) ? (len-1-i) : i]);
      *out << ( (i < len-1) ? "\t" : "\n");
    }
    return true;
  }

  bool InputData::sortFile(FileType filetype, Format unsortedFormat, Format sortedFormat, 
			   const std::string & unsortedPath, const std::string & sortedPath) {
    // sorts a file 
    assert(sortedFormat & (kSortedByNgramFormat | kSortedByValueFormat));
    assert(sortedPath != unsortedPath);
    assert(!inconsistentSort(sortedFormat));
     // determine which fields to sort by
    int startpos(0), endpos(0); 
    if (sortedFormat & kSortedByValueFormat) {
      startpos = 1;
      endpos = (filetype == kBackoffModelFileType) ? 2 : 1; // two values for bo
    } else {
      if (filetype == kCorpusFileType)
	startpos = 1;
      else
	startpos = (filetype == kBackoffModelFileType) ? 3 : 2; // two values for bo
      endpos = startpos + order_;
    }
    // set up sort flags (use numeric sort if sort by value or ngram was integerised).
    std::string flags = "--compress-program="+compress_cmd_+" -T " + tmp_dir_ + " -S " + RandLMUtils::FloatToString(working_mem_) + "M "
      + ( (unsortedFormat & kIntegerisedFormat) | (sortedFormat & kSortedByValueFormat) ? "-n " : "") 
      + ( (sortedFormat & kSortedByValueFormat) ? "-r " : "" );
    for (int i = startpos; i <= endpos; ++i)
      flags += "-k " + RandLMUtils::IntToStr(i) + " ";
    // construct appropriate command to sort ngram tokens
    std::string sortCmd = "cat " + unsortedPath + " | " + decompress_cmd_ + " | sort " + flags 
      + " | " + compress_cmd_ + " > " + sortedPath;
    std::cerr << sortCmd << std::endl;
    assert(system(sortCmd.c_str()) == 0);  // i.e. okay
    // if specified 'cleanup' save space by removing original unsorted file
    if (clean_up_) {
      std::cerr << "rm " << unsortedPath << std::endl;
      system(("rm "+unsortedPath).c_str());
    }
    return true;
  }

  // class Corpus wraps a raw corpus (or stdin)
  bool Corpus::normalise(Format outputFormat, NormalisedNgramFile* & normalisedFile) {
    // check consistent normalisation
    assert(!inconsistentSort(outputFormat));
    // first count ngrams in corpus
    CountFile* countFile = NULL;
    outputFormat |= kNormalisedFormat;
    // count ngrams file will also be sorted by ngram 
    Format simpleFormatting = outputFormat & (kIntegerisedFormat | kReversedNgramsFormat);
    assert(countNgrams(simpleFormatting, countFile));
    assert(countFile != NULL);
    // then apply other formatting
    assert(countFile->normalise(outputFormat, normalisedFile));
    delete countFile;  // delete intermediate format
    return (normalisedFile != NULL); // now points to fully formatted count file
  }

  bool Corpus::countNgrams(Format tokenisedFormat, CountFile* & countFile) {
    // manages process of conversion from raw corpus to ngram count files
    // determine files for both tokens and counts
    std::string tokenPath = getOutputPath(kTokenFileSuffix, tokenisedFormat);
    // tokenise corpus (output reversed ngrams as strings or WordIDs)
    assert(generateNgramTokens(tokenisedFormat, tokenPath));
    std::string sortedTokenPath = getOutputPath(kTokenFileSuffix, tokenisedFormat | kSortedByNgramFormat);
    std::string countPath = getOutputPath(kCountFileSuffix, tokenisedFormat | kSortedByNgramFormat);
    // sort ngram tokens
    assert(sortFile(kCorpusFileType, tokenisedFormat, tokenisedFormat | kSortedByNgramFormat,
		    tokenPath, sortedTokenPath));
    // append count to each distinct ngram type at end of line
    assert(countTypes(sortedTokenPath, countPath));
    // create CountFile, associate new input file 'countPath' and current vocab
    // specify formatting for this file
    countFile = new CountFile(this, countPath, InputData::kCountFileType, 
			      tokenisedFormat | kSortedByNgramFormat | kNormalisedFormat);
    return (countFile != NULL);
  }

  bool Corpus::generateNgramTokens(Format outputFormat,
				   const std::string & tokenPath) {
    // determine path (don't apply compression)
    RandLMFile tokenFile(tokenPath, std::ios::out);
    WordID sentence[Corpus::kMaxSentenceWords];
    int len = 0;
    assert(reset());
    assert(line_num_ == 0); // only generate tokens on full corpus
    // iterate over corpus
    while (nextSentence(&sentence[0], &len)) {
      // write out ngram tokens of all orders to file
      for (int n = 1; n <= order_; ++n)
	for (int i = 0; i < len - (n - 1); ++i)
	  assert(writeNgram(&sentence[i], n, &tokenFile, outputFormat));
    }
    return true;
  }
  
  bool Corpus::countTypes(const std::string & sortedTokenPath,  const std::string & countsPath) {
    // counts a sorted file n-gram tokens.
    // appends count to end of each distinct ngram (i.e uniq -c)
    RandLMFile sortedTokens(sortedTokenPath, std::ios::in); 
    RandLMFile countedTokens(countsPath, std::ios::out); 
    std::string line;
    Word prev_ngram[RandLM::kMaxNgramOrder];
    Word this_ngram[RandLM::kMaxNgramOrder];
    bool new_type = false;
    float count(0);
    uint64_t token(0);
    int prev_len(0), this_len(0);
    Value value;
    // store stats for these counts (and histories)
    stats_->start();
    // iterate over sorted token file
    while (getline(sortedTokens, line)) {
      std::istringstream thisline(line);
      this_len = 0;
      new_type = false;
      while (thisline >> this_ngram[this_len] && this_len < order_) {
	// if this_ngram is longer or differs on any token then signal a new type
	if(!new_type && (this_len >= prev_len || this_ngram[this_len] != prev_ngram[this_len]))
	  new_type = true;
	++this_len;
      }
      // if this_ngram is a prefix of prev_ngram we won't have spotted the difference above
      new_type |= this_len < prev_len;
      // if different then output count and copy new ngram across
      if (new_type) {
	if (token > 0) {  // output count 
	  countedTokens << count << "\t"; 
	  // store statistics
	  CountFile::convertToValue(count, &value);
	  stats_->observe(prev_ngram, value, prev_len);
	}
	for (int i = 0; i < prev_len; ++i) {
	  if (token > 0) // don't output if the first line in file
	    countedTokens << prev_ngram[i] << ((i == prev_len - 1) ? "\n" : "\t");
	  if (i < this_len)
	    prev_ngram[i] = this_ngram[i]; 
	}
	// if new ngram is longer copy it's remaining tokens 
	for(int j = prev_len; j < this_len; ++j) 
	  prev_ngram[j] = this_ngram[j]; 
	count = 0;
	prev_len = this_len;
      }
      // count this_ngram
      ++count;
      ++token;
    }
    // output final type in file
    countedTokens << count << "\t";
    // store statistics
    CountFile::convertToValue(count, &value);
    stats_->observe(this_ngram, value, this_len); 
    for(int i = 0; i < this_len; i++)
      countedTokens << this_ngram[i] << ((i == this_len - 1) ? "\n" : "\t");
    // if specified 'cleanup' save space by removing sorted tokens file
    if (clean_up_) {
      std::cerr << "rm " << sortedTokenPath << std::endl;
      system(("rm "+sortedTokenPath).c_str());    
    }
    stats_->finish();
    return true;
  }
  
  bool Corpus::nextSentence(WordID* sentence, int* len) {
    // get sentence, adding BOS / EOS if required 
    std::string line;
    while(getline(*source_, line)) {
      ++line_num_;
      // we assume that data is tokens (see checkConsistency())
      std::istringstream sent(line.c_str());
      Word word;
      *len = 0;
      // add BOS if needed
      if (add_bos_eos_)
	sentence[(*len)++] = vocab_->getWordID(Vocab::kBOS);
      // get tokens
      while(sent >> word && *len < Corpus::kMaxSentenceWords)
	sentence[(*len)++] = vocab_->getWordID(word);
      // only add EOS if needed
      if (add_bos_eos_)
	sentence[(*len)++] = vocab_->getWordID(Vocab::kEOS);
      // must have some data as well as optional <s> </s> and one value if ngram file
      if(*len > 2  || (!add_bos_eos_ && *len > 0))
	return true;
      //else 
      //	std::cerr << "WARNING: empty line " << line_num_ << " in corpus file!\n";
    }
    return false;
  }

  bool Corpus::checkConsistency() {
    // insist that no formatting has been applied.
    if (input_type_ != InputData::kCorpusFileType) {
      std::cerr << "Corpus can only wrap data of type: " << InputData::kCorpusFileType 
		<< " not of type " << input_type_ << " as given." << std::endl;
      return false;
    }
    if (format_ != kRawFormat) {
      std::cerr << "Corpus cannot process formatted (" << (int)format_ <<") input data. Use the raw corpus.\n";
      return false;
    }
    return true;
  }
      
  // class NormalisedNgramFile wraps any ngram file with one value at start of each line

  bool NormalisedNgramFile::writeNgramAndValue(WordID* ngram, int n, Value value, RandLMFile* out, 
				     Format outputFormat) {
    // output in either normal or reversed  order and as Word or WordID
    assert(writeValue(out, value));  // handled by subclass 
    return writeNgram(ngram, n, out, outputFormat);
  }
  
  bool NormalisedNgramFile::nextEntry(WordID* ngram, int* len, Value* value) {
    // read next entry unless no more
    std::string line;
    if (!getline(*source_, line))
      return false;
    std::istringstream entry(line);
    // get value (subclass deals with counts and logprob/backoff weight pairs)
    assert(readValue(&entry, value));
    // read ngram
    return readNgram(&entry, ngram, len, format_, order_);
  }
 
  bool NormalisedNgramFile::normalise(Format outputFormat, NormalisedNgramFile*& normalisedFile) {
    // check consistency of output requirements
    assert(!inconsistentSort(outputFormat));
    // determine non-sort formatting first since this may affect sort ordering
    assert(simpleFormatting(outputFormat)); 
    // perform sort (if required)
    assert(sortFormatting(outputFormat));
    // construct new NormalisedNgramFile to wrap formatted data
    if (input_type_ == kBackoffModelFileType)
      normalisedFile = new BackoffModelFile(this, input_path_, input_type_, format_);
    else
      normalisedFile = new CountFile(this, input_path_, input_type_, format_);
    return true;
  }
  
  bool NormalisedNgramFile::simpleFormatting(Format outputFormat) {
    // change format to/from integers and reverse/unreverse ngrams as required
    Format simpleTargetFormat = outputFormat & (kIntegerisedFormat | kReversedNgramsFormat);
    Format simpleInputFormat  = format_ & (kIntegerisedFormat | kReversedNgramsFormat);
    // must match exactly since either may affect sort order later
    if (simpleTargetFormat == simpleInputFormat) 
      return true;  // nothing to be done
    std::cerr << "Applying simple formatting ... " << std::endl;
    std::string formattedPath = getOutputPath(input_type_, simpleTargetFormat);
    RandLMFile formattedFile(formattedPath, std::ios::out);
    assert(reset());
    int len = 0;
    Value value;
    WordID ngram[RandLM::kMaxNgramOrder];
    // estimate stats
    stats_->start();
    // check consistency of output requirements
    while (nextEntry(&ngram[0], &len, &value)) {
      assert(writeNgramAndValue(&ngram[0], len, value, &formattedFile, simpleTargetFormat));
      stats_->observe(&ngram[0], value, len);
    }
    stats_->finish();
    formattedFile.flush();
    // update the source file of this normalisedNgramFile to point to formatted data.
    format_ = (format_ & ~(kIntegerisedFormat | kReversedNgramsFormat)) | simpleTargetFormat;
    assert(switchSource(formattedPath));
    std::cerr << "Formatted data in: " << formattedPath << std::endl;
    return true;
  }

  bool NormalisedNgramFile::sortFormatting(Format outputFormat) {
    // determine sort order for input and output data
    assert(!inconsistentSort(outputFormat));
    // check whether we need to do any sorting
    Format inputSortFormat = format_ &  (kSortedByNgramFormat | kSortedByValueFormat);
    Format outputSortFormat = outputFormat & (kSortedByNgramFormat | kSortedByValueFormat);
    // only  actually sort if required but not present (don't do anything if sorted but not required).
    if ((outputSortFormat &  ~inputSortFormat) == 0)
      return true;
    std::cerr << "Applying sort formatting ... " << std::endl;
    // check that other formatting has already been applied (since this affects sort order)
    assert( (outputFormat & (kIntegerisedFormat | kReversedNgramsFormat)) 
	    == (format_ & (kIntegerisedFormat | kReversedNgramsFormat)) );
    // apply sort
    std::string sortedPath = getOutputPath(input_type_, outputFormat);
    assert(sortFile(input_type_, format_, outputFormat, input_path_, sortedPath));
    // update the source file of this normalisedNgramFile to point to formatted data.
    format_ = outputFormat;
    assert(switchSource(sortedPath));
    std::cerr << "Sorted data in: " << sortedPath << std::endl;
    return true;
  }

  // class ArpaFile wraps an arpa input file

  bool ArpaFile::reset() {
    // reset the file handler
    InputData::reset();
    // re-read header
    return readHeader();
  }

  bool ArpaFile::readHeader() {
    // initialise counts of ngrams
    for (int i = 0; i < RandLM::kMaxNgramOrder; ++i)
      num_ngrams_[i] = 0;
    // read until \data\ line 
    std::string line;
    current_order_ = 0;
    line_num_ = 0;
    // should be second line (at least if generated by srilm ngram-count)
    while (getline(*source_, line) && line.find("\\data\\") == std::string::npos) {
      ++line_num_;
      if (line_num_ > 2)
	return false;  // too many blank lines prior to header
    }
    // iterate over lines with format: 'ngrams <n>=<num_ngrams>'
    int order = 0;
    while (getline(*source_, line) && order < RandLM::kMaxNgramOrder
	   && line.find("ngram") == 0) {
      ++line_num_;
      ++order;
      std::istringstream info(line);
      std::string token;
      info >> token;
      assert(token == "ngram");
      assert(getline(info, token, '='));
      assert(RandLMUtils::StringToInt(token) == order);
      assert(info >> token);
      assert(RandLMUtils::StringToUint64(token) > 0);
      num_ngrams_[order-1] = RandLMUtils::StringToUint64(token);
      std::cerr << num_ngrams_[order-1] << "\t" << order << "-grams (arpa header)." << std::endl;
    }
    assert(order >= order_);
    return true;
  }

  bool ArpaFile::nextEntry(WordID* ngram, int* len, Value* value) {
    // wraps backoff entry in 64-bit value
    float logProb, backoffWeight;
    return nextBackoffEntry(ngram, len, &logProb, &backoffWeight) &&
      BackoffModelFile::convertToValue(logProb, backoffWeight, value);
  }

  bool ArpaFile::nextBackoffEntry(WordID* ngramIDs, int* len, float* logProb, float* backoffWeight) {
    // read backoff entry from standard Arpa file
    std::string fullLine= "";
    do {
      if (!getline(*source_, fullLine))
        return false;
      *len = 0;
      if (fullLine.empty()) // ignore empty lines
	continue;
      if (fullLine[0] == '\\') { // deal with new section or end of entries
	if (fullLine.find("\\end\\") == 0 || current_order_ == order_)
	  return false;
	assert(fullLine.find(RandLMUtils::IntToStr(++current_order_)) == 1);
	std::cerr << "Processing " << current_order_ << "-grams." << std::endl;
	continue;
      }
      // tokenise
      std::string token;
      std::istringstream entry(fullLine);
      assert(entry >> *logProb);  
      while (*len < current_order_ && entry >> token)
	ngramIDs[(*len)++] = vocab_->getWordID(token); 
      assert(*len == current_order_);
      if (!(entry >> *backoffWeight)) {
	*backoffWeight = BackoffModelFile::kNullBackoffWeight;
      } 
      break;
    } while (1);
    return true;
  }
  bool BackoffModelFile::ValidWeight(float boweight) {
    return boweight < 0 || boweight > 0;
  }

  bool ArpaFile::normalise(Format outputFormat,
			   NormalisedNgramFile* & normalisedFile) {
    // convert arpa format data to normalised format and then
    // pass on request for any other formatting requirments
    int len;
    //float logProb, backoffWeight;
    WordID ngram[RandLM::kMaxNgramOrder];
    // add normalized
    outputFormat |= kNormalisedFormat; 
    // normalised format will not be sorted
    Format normalisedFormat = outputFormat & ~(kSortedByNgramFormat | kSortedByValueFormat); 
    // setup output path for normalised data 
    std::string normPath = getOutputPath(kBackoffModelFileSuffix, normalisedFormat);
    RandLMFile normFile(normPath, std::ios::out);
    // estimate stats as well
    stats_->start();
    // iterate over the complete arpa file
    assert(reset());
    //while(nextBackoffEntry(&ngram[0], &len, &logProb, &backoffWeight)) {
    Value value;
    while(nextEntry(&ngram[0], &len, &value)) {
      normFile << value.uint << "\t";
      assert(writeNgram(&ngram[0], len, &normFile, normalisedFormat));
      stats_->observe(&ngram[0], value, len);
    }
    stats_->finish();
    normFile.flush(); // ensure output in buffer expunged 
    // new BackoffModelFile wrapping normalized data
    BackoffModelFile backoffFile(this, normPath, kBackoffModelFileType, normalisedFormat);
    // apply other formatting
    std::cerr << "Normalised Arpa file: " << normPath << std::endl;
    assert(backoffFile.normalise(outputFormat, normalisedFile));
    return (normalisedFile != 0);
  }

  // class CountFile wraps a file of ngram counts
  bool CountFile::reset() { 
    assert(InputData::reset());
    // also reset structures for counting histories 
    for (int i = 0; i < order_; ++i)
      first_entry_[i] = true;
    final_history_index_ = 0;
    pending_len_ = 0;
    pending_count_ = 0;
    return true;
  }

  bool CountFile::readValue(std::istringstream* entry, Value* value) {
    // read two values from input stream and convert to one value
    float count(0),history(0);
    assert(*entry >> count);
    return convertToValue(count, history, value);
  }

  bool CountFile::writeValue(RandLMFile* out, Value value) {
    // read two values from input stream and convert to one value
    float count(0),history(0);
    assert(convertFromValue(value, &count, &history));
    *out << count << "\t";
    return true;
  }
  bool CountFile::convertToValue(float count, Value* value) {
    value->floats[0] = count;
    value->floats[1] = 0;
    return true;
  }
  bool CountFile::convertToValue(float count, float history, Value* value) {
    // pack two floats into one uint64 (value)
    value->floats[0] = count;
    value->floats[1] = history; 
    return true;
  }
  // TODO: unbreak this code for counts > 2^32
  bool CountFile::convertFromValue(Value value, float* count, float* history) {
    *count = value.floats[0];
    *history = value.floats[1];
    return true;
  }

  bool CountFile::nextEntry(WordID* ngram, int* len, Value* value) {
    // get next ngram count (if one) and count histories on fly (if sorted by ngrams)
    if (!(format_ & kSortedByNgramFormat))
      return NormalisedNgramFile::nextEntry(ngram, len, value);
    float count(0),history(0);
    // deal with pending ngram from previous call
    if (pending_len_ > 0) {
      *len = pending_len_;
      for (int i = 0; i < pending_len_; ++i)
	ngram[i] = pending_entry_[i];
      count = pending_count_;
      CountFile::convertToValue(count, history, value);
      pending_len_ = 0;
      pending_count_ = 0;
      return true;
    }
    // otherwise read next entry from disk
    if (!NormalisedNgramFile::nextEntry(ngram, len, value)) {
      // no more ngram counts but might need to retrieve history counts
      while(++final_history_index_ < order_) { 
	if (!first_entry_[final_history_index_]) {
	  for (int i = 0; i < final_history_index_; ++i)
	    ngram[i] = this_history_[final_history_index_][i];
	  // set history from record
	  history = this_history_count_[final_history_index_];
	  ngram[final_history_index_] = Vocab::kOOVWordID; // pad last word
	  *len = final_history_index_ + 1; // ngram length 
	  // convert count = 0  and history to value
	  return CountFile::convertToValue(count, history, value);
	}
      }
      return false; // no kind of any count
    }
    // just return unigrams since no histories
    if (*len < 2)
      return true;
    // deal with history record if first entry of this length just store
    if (first_entry_[*len - 1]) { 
      for (int i = 0; i < *len - 1; ++i)
	this_history_[*len - 1][i] = ngram[i];
      first_entry_[*len - 1] = false;
      this_history_count_[*len - 1] = 1;
      return true; 
    }
    // determine whether the history is new 
    bool same = true;
    int i = 0;
    while(same && (i < *len - 1)){
      same = same && (ngram[i] == this_history_[*len - 1][i]);
      ++i;
    }
    // still same history so just increment current count
    if (same) { 
      ++this_history_count_[*len - 1];
      return true;
    }
    // different history so pend this ngram 
    pending_len_ = *len;
    for (int i = 0; i < pending_len_; ++i)
      pending_entry_[i] = ngram[i];
    CountFile::convertFromValue(*value, &pending_count_, &history);
    // get old history and its count
    history = this_history_count_[*len - 1];
    for (int i = 0; i < *len - 1; ++i)
      ngram[i] = this_history_[*len - 1][i];
    ngram[*len - 1] = Vocab::kOOVWordID;
    history = this_history_count_[*len - 1];
    // set new history
    this_history_count_[*len - 1] = 1;
    for (int i = 0; i < *len - 1; ++i)
      this_history_[*len - 1][i] = pending_entry_[i];
    CountFile::convertToValue(count, history, value);
    return true;
  }

  // class BackoffModelFile wraps a normalised backoff model
  const float BackoffModelFile::kNullBackoffWeight;

  bool BackoffModelFile::nextBackoffEntry(WordID* ngram, int* len, float* logProb, 
					  float* backoffWeight) {
    Value value;
    if (nextEntry(ngram, len, &value))
      return convertFromValue(value, logProb, backoffWeight);
    return false;
  }

  bool BackoffModelFile::convertToValue(float logProb, float backoffWeight, Value* value) {
    value->floats[0] = logProb; // RandLMUtils::Round(logProb, 7);
    value->floats[1] = backoffWeight; // RandLMUtils::Round(backoffWeight, 7);
    return true;
  }

  bool BackoffModelFile::convertFromValue(Value value, float* logProb, float* backoffWeight) {
    *logProb = value.floats[0];
    *backoffWeight = value.floats[1];
    return true;
  }
  
  bool BackoffModelFile::readValue(std::istringstream* entry, Value* value) {
    // read uint64 from file
    assert(*entry >> value->uint);
    return true;
  }

  bool BackoffModelFile::writeValue(RandLMFile* out, Value value) {
    // write as uint64
    *out << value.uint << "\t";
    return true;
  }

} // ends namespace
