// Copyright 2008 David Talbot, Abby Levenberg
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_PREPROC_H
#define INC_RANDLM_PREPROC_H

#include <map>
#include <vector>
#include <iterator>
#include <cassert>
#include <string>
#include "RandLM.h"
#include "RandLMTypes.h"
#include "RandLMUtils.h"
#include "RandLMFile.h"

#include <iostream>

namespace randlm {

  // InputData: Wrappers for different data formats
  // All wrapper constructors take path to their data source and a vocab object that
  // is owned by the RandLMBuilder.

  // At the start of the pipeline the public constructor is used to parse
  // a RandLMParams object and set various file related parameters. These
  // are then passed down the pipeline via a protected constructor that
  // allows certain InputData subclasses to generate other subclass instances.

  // friendships determine which data formats can be converted into which other ones.


  // Format
  // 0 - normalised
  // 1 - integerised
  // 2 - sorted by ngram
  // 3 - sorted by value
  // 4 - reverse ngrams

  class NormalisedNgramFile;  // forward declaration: <value> <word> ...   
  class Vocab;
  class Stats;

  // Abstract base class for any input data. 
  class InputData {

  public:
    // Formats codes
    // Use each bit to represent a boolean formatting attribute
    const static int kNormalisedBit = 0;
    const static int kIntegerisedBit = 1;
    const static int kSortedByNgramBit = 2;
    const static int kSortedByValueBit = 3;
    const static int kReversedNgramsBit= 4;

    const static Format kRawFormat = 0;
    const static Format kNormalisedFormat = 1 << 0; //kNormalisedBit;
    const static Format kIntegerisedFormat = 1 << 1; //kIntegerisedBit;
    const static Format kSortedByNgramFormat = 1 << 2; //kSortedByNgramBit;
    const static Format kSortedByValueFormat = 1 << 3; //kSortedByValueBit;
    const static Format kReversedNgramsFormat = 1 << 4; //kReversedNgramsBit;

    const static Format kNullFormat = 1 << 5;
    // input file types (specified via command line)
    static const std::string kNullFileType;
    static const std::string kNgramsFileType;
    static const std::string kCorpusFileType;
    static const std::string kArpaFileType; 
    static const std::string kCountFileType;  
    static const std::string kBackoffModelFileType; 

    // file type suffixes (added to files created in pipeline for information only).
    static const std::string kTokenFileSuffix; 
    static const std::string kNormalisedFileSuffix; 
    static const std::string kReversedFileSuffix;
    static const std::string kIntegerisedFileSuffix;
    static const std::string kCountFileSuffix;
    static const std::string kBackoffModelFileSuffix;
    static const std::string kStatsFileSuffix;
    static const std::string kWordCountFileSuffix;
    static const std::string kVcbFileSuffix;

    // public constructor used at start of pipeline
    InputData(const std::string & input_path, const std::string & input_type,
	      const std::string & tmp_dir, const std::string & output_prefix, const std::string output_dir,
	      float working_mem, int order, bool clean_up, Format format, Vocab* vocab, Stats* stats) {
      // copy main parameters 
      input_path_ = input_path;
      input_type_ = input_type;
      tmp_dir_ = tmp_dir;
      output_prefix_ = output_prefix;
      output_dir_ = output_dir;
      working_mem_ = working_mem;
      assert(order <= RandLM::kMaxNgramOrder);
      order_ = order;
      clean_up_ = clean_up;
      format_ = format;
      assert(!inconsistentSort(format_));
      assert(vocab != NULL);
      vocab_ = vocab;  // owned by pipeline
      stats_ = stats;  // owned by pipeline
      assert(init());
    }
    bool init(){ 
      // setup other params
      RandLMFile::getCompressionCmds(input_path_, compress_cmd_, 
				     decompress_cmd_, compression_suffix_);
      line_num_ = 0;
      // open the source file
      source_ = new RandLMFile(input_path_, std::ios::in);
      return (source_ != NULL);
    }
    // never delete the vocab (it's owned by the pipeline).
    virtual ~InputData() { delete source_; }
    // perform some kind of 'normalisation' on input data 
    // 'normalisedFile' points to the new InputData
    virtual bool normalise(Format outputFormat, 
			   NormalisedNgramFile* & normalisedFile) = 0;
    // reset input file
    virtual bool reset();
    uint64_t getLineNumber() { return line_num_; }
    virtual bool switchSource(std::string & newSourcePath);
    // get word count
    bool getWordCount(uint64_t* lines, uint64_t* tokens, uint64_t* bytes);
    uint64_t getWordCount() {
      uint64_t lines(0),tokens(0),bytes(0);
      assert(getWordCount(&lines, &tokens, &bytes));
      return tokens;
    }
    // determine current input data formatting
    bool isNormalised() { return format_ &  kNormalisedFormat; }
    bool isIntegerised() { return format_ & kIntegerisedFormat; }
    bool isSortedByNgram() { return format_ & kSortedByNgramFormat; }
    bool isSortedByValue() { return format_ & kSortedByValueFormat; }
    bool ngramsAreReversed() { return format_ & kReversedNgramsFormat; }
    bool isCountData() { return input_type_ == kCountFileType; }
    bool isCorpusData() { return input_type_ == kCorpusFileType; }
    bool isBackoffData() { 
      return input_type_ == kArpaFileType || input_type_ == kBackoffModelFileType;
    }
    bool isCorpus() { return input_type_ == kCorpusFileType; }
    FileType getInputType() { return input_type_; }
    Format getFormat() { return format_; }
    std::string getVocabPath() { return getOutputPath(kVcbFileSuffix, kNullFormat); }
    std::string getStatsPath() { return getOutputPath(kStatsFileSuffix, kNullFormat); }
    std::string getWordCountPath() { return getOutputPath(kWordCountFileSuffix, kNullFormat); }
  protected:
    // used to instantiate a new InputData with
    // (potentially) a new input path and type as well as new formatting.
    InputData(const InputData* input_data, const std::string & input_path, 
	      const std::string & input_type, Format format) {
      // check parameters are okay
      assert(input_path.length() > 0);
      input_path_ = input_path;
      assert(input_type.length() > 0);
      input_type_ = input_type;
      assert(input_data != NULL);
      // copy across member data that remains unchanged
      vocab_ = input_data->vocab_;
      stats_ = input_data->stats_;
      tmp_dir_ = input_data->tmp_dir_;
      output_prefix_ = input_data->output_prefix_;
      output_dir_ = input_data->output_dir_;
      working_mem_ = input_data->working_mem_;
      order_ = input_data->order_;
      clean_up_ = input_data->clean_up_;
      // check formatting of new source
      assert(!inconsistentSort(format));
      // assign formatting
      format_ = format;
      assert(init());
    }
    // resolves path for various files based on parameters and formatting
    std::string getOutputPath(const std::string & fileSuffix, 
			      Format outputFormat);
    // formatted ngram entries
    bool readNgram(std::istringstream* entry, WordID* ngram, int* len, Format format, int maxLen);
    bool writeNgram(WordID* ngram, int len, RandLMFile* out, Format outputFormat);
    bool sortFile(FileType filetype, Format unsortedFormat, Format sortedFormat,
		  const std::string & unsortedPath, const std::string & sortedPath);
    // avoid conflicting sort functions
    bool inconsistentSort(Format format) {    
      return (format & kSortedByNgramFormat) && (format & kSortedByValueFormat); 
    }
    // make sure the formatting parameters have been set as expected
    bool checkFormatting(Format format) { return (format = format_); }
    // member data
    std::string input_path_;  // path to data source (may be std::cin)
    std::string input_type_;  // type of data
    Format format_;   // representation of formatting attributes (see typedef).
    std::string tmp_dir_;  // temporary directory 
    std::string output_prefix_; // prefix for all output files
    std::string output_dir_; // directory for all output files
    Vocab* vocab_;  // pipeline vocab (not owned)
    Stats* stats_;  // pipeline stats 
    float working_mem_;  // megabytes of working memory
    int order_; // ngram order
    bool clean_up_;  // delete intermediate files
    // derived parameters
    std::string compression_suffix_; // file suffix indicating compression format
    std::string compress_cmd_; // command to compress and write to std::cout
    std::string decompress_cmd_;  // command to decompress and write to std::cout 
    uint64_t line_num_;   // line number in file
    RandLMFile* source_;  // input data (owned)
  };

  // Corpus wraps a raw tokenised corpus (possibly passed via stdin).

  class CountFile;  // forward declaration: <count> <word> <word>

  class Corpus : public InputData {
  public:
    static const int kMaxSentenceWords = 512;
    static const int kMaxSentenceBytes = 4096;
    // Corpus can only be instantiated at start of pipeline
    Corpus(const std::string & input_path, const std::string & input_type,
	   const std::string & tmp_dir, const std::string & output_prefix, 
	   const std::string output_dir, float working_mem, int order, 
	   bool clean_up, Format format, Vocab* vocab, Stats* stats, bool addboseos = true) :
      InputData(input_path, input_type, tmp_dir, output_prefix, output_dir,
		working_mem, order, clean_up, format, vocab, stats), add_bos_eos_(addboseos) {
      assert(checkConsistency());
    }
    virtual ~Corpus(){}  // base class cleans up source
    // generate normalised ngram file with specified formatting
    bool normalise(Format outputFormat, NormalisedNgramFile* & normalisedFile);
    // Construct ngram count files (possibly sorted by reverse ngram order).
    bool countNgrams(Format outputFormat, CountFile* & countFile);
    // Called by RandLM that can read corpus data directly. Used by 'countNgrams' above.
    bool nextSentence(WordID* sentence, int* len);  // read next sentence from corpus
  protected:
    // check that input_type is consistent
    bool checkConsistency();
    bool generateNgramTokens(Format outputFormat, const std::string & tokenPath);
    bool sortTokens(const std::string & tokenPath, const std::string & sortedTokenPath);
    bool countTypes(const std::string & sortedTokenPath, const std::string & countPath);
    bool add_bos_eos_;  // whether to add <s> </s>
  };
  
  // Restrictive subclass of Corpus used for reading in and processing test corpora
  class TestCorpus : public Corpus {
  public:
    TestCorpus(const std::string & path, Vocab* vocab, int order, bool addboseos) :
      Corpus(path, kCorpusFileType, "", "", "", 0, order, false, kRawFormat, 
	     vocab, NULL, addboseos) {      
      assert(vocab != NULL && vocab->isClosed());
    }
    // should really override other functions that don't make sense...
  };
  // NgramFile: Abstract class wrapper for all ngram based file formats.
  // direct subclasses are the abstract NormalisedNgramFile and the concrete ArpaFile
  class NgramFile : public InputData {
  public:
    NgramFile(const std::string & input_path, const std::string & input_type,
	      const std::string & tmp_dir, const std::string & output_prefix, 
	      const std::string output_dir, float working_mem, int order, 
	      bool clean_up, Format format, Vocab* vocab, Stats* stats) :
      InputData(input_path, input_type, tmp_dir, output_prefix, output_dir,
		working_mem, order, clean_up, format, vocab, stats) {
      assert(checkConsistency());
    }
    ~NgramFile() {}  // we don't own source file or vocab
    // called to iterate through the file
    virtual bool nextEntry(WordID* ngram, int* len, Value* value) = 0;
    bool getStats();
  protected:
    // used within pipeline
    NgramFile(const InputData* input_data, const std::string & input_path,
	      const std::string & input_type, Format format) 
      : InputData(input_data, input_path, input_type, format) {
      assert(checkConsistency());
    }
    bool checkConsistency() {
      return (input_type_ == InputData::kCountFileType ||
	      input_type_ == InputData::kArpaFileType ||
	      input_type_ == InputData::kBackoffModelFileType);
    }
  };

  // Wrapper to standard arpa format
  class ArpaFile : public NgramFile {
  public:
    // Arpa files can only be instantiated at start of pipeline since
    // we never generate an arpa file as output.
    ArpaFile(const std::string & input_path, const std::string & input_type,
	     const std::string & tmp_dir, const std::string & output_prefix, 
	     const std::string output_dir, float working_mem, int order, 
	     bool clean_up, Format format, Vocab* vocab, Stats* stats) :
      NgramFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
		working_mem, order, clean_up, format, vocab, stats), current_order_(0) {
      assert(checkConsistency());
    }
    // reset
    bool reset();
    // get next entry 
    bool nextEntry(WordID* ngram, int* len, Value* value);
    // get next entry 
    bool nextBackoffEntry(WordID* ngram, int* len, float* logProb, float* backoffWeight);
    // get normalised file from arpa file
    bool normalise(Format outputFormat, NormalisedNgramFile* & normalisedFile);
    // determine which section we're in the Arpa file (0 = header prior to unigrams)
    int getCurrentOrder() { return current_order_; }  
  protected:
    // read arpa file head with ngram stats
    bool readHeader();
    bool nextNgramOrder(std::string & line);
    bool checkConsistency() { return (input_type_ == InputData::kArpaFileType); }
    int current_order_;  // current ngram size (0 in header of arpa file).
    uint64_t num_ngrams_[RandLM::kMaxNgramOrder];  // counts of each order read from arpa header
  };
    
  // Normalized file contains n-grams with one Value (uint64_t) at the beginning of each line. 
  // Value can be interpreted as an ngram count or as a concatenation of a logprob and a backoff weight
  // (see CountFile and BackoffModelFile subclasses)
  class NormalisedNgramFile : public NgramFile {
  public:
    // creation at start of pipeline
    NormalisedNgramFile(const std::string & input_path, const std::string & input_type,
			const std::string & tmp_dir, const std::string & output_prefix, 
			const std::string output_dir, float working_mem, int order, 
			bool clean_up, Format format, Vocab* vocab, Stats* stats) :
      NgramFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
		working_mem, order, clean_up, format, vocab, stats) {
      assert(isNormalised());
      assert(checkConsistency());
    }
    // returns next ngram and value
    bool nextEntry(WordID* ngram, int* len, Value* value); 
    // generate new file according to formatting parameters
    bool normalise(Format outputFormat, NormalisedNgramFile* & processedFile);    
    bool writeNgramAndValue(WordID* ngram, int len, Value value, RandLMFile* out,
			    Format outputFormat);
    virtual bool readValue(std::istringstream* entry, Value* value) = 0;
    virtual bool writeValue(RandLMFile* out, Value value) = 0;

  protected:
    // creation within pipeline
    NormalisedNgramFile(const InputData* input_data, const std::string & input_path,
			const std::string & input_type, Format format) 
      : NgramFile(input_data, input_path, input_type, format) {
      assert(isNormalised());
      assert(checkConsistency());
    }
    bool checkConsistency() { 
      return (input_type_ == InputData::kBackoffModelFileType ||
	      input_type_ == InputData::kCountFileType); 
    }
    bool simpleFormatting(Format outputFormat);
    bool sortFormatting(Format outputFormat);
  };
  
  // Concrete subclass of NormalisedNgramFile for ngram counts  
  class CountFile : public NormalisedNgramFile {
  public:
    // create at start of pipeline
    CountFile(const std::string & input_path, const std::string & input_type,
	      const std::string & tmp_dir, const std::string & output_prefix, 
	      const std::string output_dir, float working_mem, int order, 
	      bool clean_up, Format format, Vocab* vocab, Stats* stats) :
      NormalisedNgramFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
		working_mem, order, clean_up, format, vocab, stats) {
      assert(checkConsistency());
    } 
    bool reset();  // resets history structures too
    // iterate count entries and retrieve history counts on the fly if sorted
    bool nextEntry(WordID* ngram, int* len, Value* value);
    static bool convertToValue(float count, float history, Value* value);
    static bool convertToValue(float count, Value* value);
    static bool convertFromValue(Value value, float* count, float* history);
  protected:
    // creation within pipeline
    CountFile(const InputData* input_data, const std::string & input_path,
	      const std::string & input_type, Format format) 
      : NormalisedNgramFile(input_data, input_path, input_type, format) {
      assert(checkConsistency());
    } 
    bool checkConsistency() { return (input_type_ == InputData::kCountFileType); }
    bool readValue(std::istringstream* entry, Value* value);
    bool writeValue(RandLMFile* out, Value value);
    static bool addHistoryToValue(float history, Value* value);
    // structure for counting histories
    bool first_entry_[RandLM::kMaxNgramOrder];
    uint64_t this_history_count_[RandLM::kMaxNgramOrder];
    WordID this_history_[RandLM::kMaxNgramOrder][RandLM::kMaxNgramOrder];
    WordID pending_entry_[RandLM::kMaxNgramOrder]; // holder for next ngram 
    int pending_len_; // length of next ngram
    float pending_count_;
    int final_history_index_; 
    // only a corpus or normalised ngram file can generate a countfile within the pipeline
    friend class Corpus;
    friend class NormalisedNgramFile;
  };
  
  // Concrete subclass of NormalisedNgramFile for backoff model data
  class BackoffModelFile : public NormalisedNgramFile {
  public:
    static const float kNullBackoffWeight = 0; // indicates lack of backoff weight
    static bool ValidWeight(float boweight);
    // creation at start of pipeline (i.e. load a preprocess backoff model)
    BackoffModelFile(const std::string & input_path, const std::string & input_type,
		     const std::string & tmp_dir, const std::string & output_prefix, 
		     const std::string output_dir, float working_mem, int order, 
		     bool clean_up, Format format, Vocab* vocab, Stats* stats) :
      NormalisedNgramFile(input_path, input_type, tmp_dir, output_prefix, output_dir,
			  working_mem, order, clean_up, format, vocab, stats) {
      assert(checkConsistency());
    }
    // parses uint64 Value into two float values
    bool nextBackoffEntry(WordID* ngram, int* len, float* logProb, float* backoffWeight);
    static bool convertToValue(float logProb, float backoffWeight, Value* value);
    static bool convertFromValue(Value value, float* logProb, float* backoffWeight);
  protected:
    // creation within pipeline
    BackoffModelFile(const InputData* input_data, const std::string & input_path,
		     const std::string & input_type, Format format) 
      : NormalisedNgramFile(input_data, input_path, input_type, format) {
      assert(checkConsistency());
    } 
    bool checkConsistency() { return (input_type_ == InputData::kBackoffModelFileType); }
    bool readValue(std::istringstream* entry, Value* value);
    bool writeValue(RandLMFile* out, Value value);
    // only an arpa file or normalised ngram file  can generate a backoffmodel file in the pipeline
    friend class ArpaFile;
    friend class NormalisedNgramFile;
  };
  
} // ends namespace

#endif  // RANDLM_PREPROC_H
