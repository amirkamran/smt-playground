// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include "RandLMInfo.h"
namespace randlm {

  const std::string RandLMInfo::kNullEventName = "__NULL__";
  const std::string RandLMInfo::kCountEventName = "count";
  const std::string RandLMInfo::kHistoryEventName = "history";  
  const std::string RandLMInfo::kLogProbEventName = "log-prob";
  const std::string RandLMInfo::kBackoffWeightEventName = "bo-weight";
  // composite events 
  const std::string RandLMInfo::kAnyCountEventName = "any-count";
  const std::string RandLMInfo::kAnyProbEventName = "any-prob";

  std::string RandLMInfo::getEventName(EventType event) {
    std::string name = kNullEventName;
    switch (event) {
    case kLogProbEvent:
      name = kLogProbEventName;
      break;
    case kBackoffWeightEvent:
      name = kBackoffWeightEventName;
      break;
    case kCountEvent:
      name = kCountEventName;
      break;
    case kHistoryEvent:
      name = kHistoryEventName;
      break;
    case kAnyCountEvent:
      name = kAnyCountEventName;
      break;
    case kAnyProbEvent:
      name = kAnyProbEventName;
      break;
    }
    return name;
  }

  int RandLMInfo::getNumEvents(EventType events) {
    int eventtypes = 0;
    for (uint8_t i = 0; i < sizeof(events) << 3; ++i)
      if (events & (1ull << i))
	++eventtypes;
    return eventtypes;
  }
}
