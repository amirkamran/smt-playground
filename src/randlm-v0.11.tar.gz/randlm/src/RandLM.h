// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_H
#define INC_RANDLM_H

#include "RandLMVocab.h"
#include "RandLMStruct.h"
#include "RandLMInfo.h"
#include "RandLMQuantiser.h"
#include "RandLMCache.h"
#include "RandLMHashCache.h"

// class RandLM abstract base class for language models.

// Subclasses of RandLM implement distinct smoothing algorithms

// CountRandLM is an abstract subclass that any LM containing
// counts should implement. 

// StupidBackoffRandLM and WittenBellRandLM differ in that the 
// latter stores 'history' counts as well as plain ngram counts.

// BackoffRandLM implements RandLM to store a standard backoff model
// that is defined as logprobs and backoff weights directly.

// A RandLM stores its main data in a RandLMStruct and has
// Quantiser(s) to map from either probabilities or counts to
// integer codes that are stored in the RandLMStruct.

// Current implementations assume that at most two distinct types
// of events are stored in a RandLM. These are generically
// referred to as the 'main_event' and the 'aux_event'. For instance
// main_event could be ngram counts and aux_event could be suffix
// (history) counts. 

// A new RandLM can be built from data using the buildlm tool
// which is implemented in class RandLMBuilder. 

// An existing RandLM can be loaded from file and queried using
// the querylm tool implemented in class RandLMQuery.

// To build a RandLM we require statistics regarding the data
// that will be stored to optimise space/error requirements.
// When used in batch estimation mode the buildlm tool
// uses the quantiser and the statistics to inform the 
// RandLMStruct exactly how many ngrams with each code
// will be inserted.

namespace randlm {

  class InputData; 
  class Corpus;
  class NgramFile;
  class Stats;

  class RandLM {
  public:  
    static const int kMaxNgramOrder = 10;
    static const std::string kNullSmoothing;
    static const std::string kStupidBackoffSmoothing;
    static const std::string kWittenBellSmoothing;
    static const std::string kBackoffSmoothing;

    static const int kNullSmoothingCode = 0;
    static const int kStupidBackoffSmoothingCode = 1;
    static const int kWittenBellSmoothingCode = 2;
    static const int kBackoffSmoothingCode = 3;

    static const std::string kRandLMFileType;

    static const float kNullLogProb = -1000000;
    static const float kUnknownLogProb = 1000000;

    static const int kMainEventIdx = 0;
    static const int kAuxEventIdx = 1;
    
    static const int kNoChecks = 0;
    static const int kStandardChecks = 1;
    static const int kAllChecks = 2;

    static std::string getSmoothingName(Smoothing scheme);
    static bool getSmoothingCode(const std::string & smoothing_name, Smoothing* scheme);
    static bool getDefaultSmoothing(StructCode code, FileType input_type, Estimator estimator,
				    Smoothing* scheme);
    static bool getRequiredEventType(Smoothing scheme, EventType* events);
    static bool getInputRequirements(RandLMInfo* info, FileType inputType, Format inputFormat, 
				     FileType* requiredInputType, Format* requiredInputFormat);
    static RandLM* initRandLM(const std::string& filename, int order, int cache_size);
    static RandLM* initRandLM(RandLMInfo* info, Vocab* vocab);
    static RandLM* initRandLM(RandLMInfo* info, RandLMFile* fin, int checks = RandLM::kNoChecks);

    // used for building a new RandLM
    RandLM(RandLMInfo* info, Vocab* vocab) 
      : info_(info), vocab_(vocab), struct_(NULL), num_ngrams_(NULL), distinct_unigrams_(0),
      uniform_log10prob_(0), total_(0), order_(0),
      main_event_(RandLMInfo::kNullEvent), aux_event_(RandLMInfo::kNullEvent), 
      checks_(RandLM::kNoChecks), built_(false), max_codes_(0), probCache_(NULL) {
      assert(info != NULL && vocab != NULL);
      // check struct is suitable for storing this kind of data
      assert(RandLMStruct::canStore(info->getStructType(), info->getEventType()));
      // set up randomised data structure to hold model
      struct_ = RandLMStruct::initStruct(info_);
      assert(struct_ != NULL);
      // setup other data 
      assert(initMembers());
    }
    // used for loading RandLM from file
    RandLM(RandLMInfo* info, RandLMFile* fin, int checks = RandLM::kNoChecks) 
      : info_(info), vocab_(NULL), struct_(NULL), num_ngrams_(NULL), distinct_unigrams_(0),
      uniform_log10prob_(0), total_(0), order_(0),
      main_event_(RandLMInfo::kNullEvent), aux_event_(RandLMInfo::kNullEvent),
      checks_(checks), built_(false), max_codes_(0), probCache_(NULL) {
      assert(info_ != NULL && fin != NULL);
      std::cerr << "Check level = " << checks_ << std::endl;
      // set up other member data structures
      assert(initMembers());
      // load member data for base
      assert(load(fin));
    }
    virtual ~RandLM() {
      delete info_;
      delete vocab_;
      delete struct_;
      delete[] num_ngrams_;
      delete[] max_codes_;
      delete probCache_;
    }
  public:
    // get conditional prob of ngram
    virtual float getProb(const WordID* ngram, int len, int* found, const void** state = 0) = 0;
    // add data to model
    virtual bool build(InputData* input_data, Stats* stats, float working_mem);
    // get word id
    WordID getWordID(const std::string& word) {
      return vocab_->getWordID(word);
    }
    Word getWord(WordID id) {
      return vocab_->getWord(id);
    }
    Vocab* getVocab() {
      assert(vocab_ != NULL);
      return vocab_;
    }
    virtual bool clearCaches() = 0;
    // accessors
    int getOrder() { return info_->getMaxOrder(); }
    bool save(const std::string & path); 
    // methods used by moses to set up mapping from factorIDs to wordIDs
    const std::string & getOOV();
    const std::string & getBOS();
    const std::string & getEOS();
    std::map<Word, WordID>::const_iterator vocabStart() const {
      return vocab_->vocabStart();
    }
    std::map<Word, WordID>::const_iterator vocabEnd() const {
      return vocab_->vocabEnd();
    }
  protected:
    bool cachedQuery(const WordID* ngram, int len, int event_idx, int cached, int* code, 
		     int max = RandLMStruct::kMaxCode) {
      return cached != RandLMStruct::kNullCode && 
	(cached != RandLMStruct::kUnknownCode || struct_->query(ngram, len, event_idx, code, max));
    }
    // instantiate model structures
    bool initRandLMStruct();   // setup randomised structure
    bool initMembers();  // setup other data members
    bool load(RandLMFile* fin);  // load data members
    virtual bool save(RandLMFile* fout); // main parameters
    // setup and build a new model
    virtual bool setupQuantisers(Stats* stats) = 0;  // build quantisers
    virtual bool setupMaxCodes() = 0;  //
    bool specifyBatch(EventType event, Stats* stats, Quantiser* quantiser);  // specify data to be stored
    virtual bool optimiseStruct(Stats* stats, float working_mem) = 0;  // optimise RandLMStruct
    virtual bool build(InputData* data);     // add data 
    bool buildFromNgrams(NgramFile* ngrams);  
    virtual bool storeNgram(const WordID* ngram, int len, Value value) = 0;
    // persistent data (written to file)
    RandLMInfo* info_; // meta data 
    Vocab* vocab_;  // vocab mapping
    RandLMStruct* struct_;  // structure holding LM data
    uint64_t* num_ngrams_;  // distinct ngrams in model
    uint64_t distinct_unigrams_; // number of distinct words in total vocab
    float uniform_log10prob_;  // log of ratio of 'new' words to corpus size 
    uint64_t total_;  
    // infered data 
    int order_;
    EventType main_event_;  // event types treated as main and auxiliary respectively
    EventType aux_event_;
    int checks_;  // level of checks to apply for subngrams
    bool built_;
    int* max_codes_;  // largest code supported by quantiser for each event type
    int num_events_;  // how many events stored (currently only 1 or 2)
    RandLMHashCache* probCache_;
  };

  // CountRandLM provides interface for storing/querying count data
  class CountRandLM : public RandLM {
  public:
    CountRandLM(RandLMInfo* info, Vocab* vocab) :
      RandLM(info, vocab), log_quantiser_(NULL), online_struct_(NULL),
      corpus_size_(0), countCodeCache_(NULL) {
      // check we're storing counts (no restrictions on struct)
      assert(info->getEventType() & RandLMInfo::kCountEvent);
      // check not storing logprobs/bo weights
      assert(~(info->getEventType() & RandLMInfo::kAnyProbEvent));
      // setup any other data structures
      assert(initMembers());
    }
    CountRandLM(RandLMInfo* info, RandLMFile* fin, int checks) :
      RandLM(info, fin, checks), log_quantiser_(NULL), online_struct_(NULL),
      corpus_size_(0), countCodeCache_(NULL) {
      // check we're storing counts (no restrictions on struct)
      assert(info->getEventType() & RandLMInfo::kCountEvent);
      // check not storing logprobs/bo weights
      assert(~(info->getEventType() & RandLMInfo::kAnyProbEvent));
      // setup any other data structures
      assert(initMembers());
      assert(load(fin));
    }
    virtual ~CountRandLM() {
      delete log_quantiser_; 
      delete countCodeCache_;
    }
    // return conditional prob (implementations determine smoothing algorithm)
    virtual float getProb(const WordID* ngram, int len, int* found, const void** state = 0) = 0;
    // retrieve count for this ngram
    float getCount(const WordID* ngram, int len);
    bool clearCaches() {
      return probCache_->clearCache() && countCodeCache_->clearCache();
    }
  protected:
    // i/o 
    bool load(RandLMFile* fin);
    virtual bool save(RandLMFile* fin);
    // initialisation 
    bool initMembers();
    // functions used during building of new model 
    virtual bool build(InputData* data);
    virtual bool buildFromCorpus(Corpus* corpus);
    bool setupQuantisers(Stats* stats);
    bool setupMaxCodes();
    virtual bool optimiseStruct(Stats* stats, float working_mem);
    virtual bool storeSentence(const WordID* sentence, int len);
    virtual bool storeNgram(const WordID* ngram, int len, Value value);
    // member data
    LogQuantiser* log_quantiser_;   // quantiser for counts
    OnlineRandLMStruct* online_struct_;  // downcast version of RandLM's struct_ member
    uint64_t corpus_size_;  // tokens in corpus
    RandLMCache<int>* countCodeCache_;
  };
  
  // StupidBackoffRandLM implements stupid backoff to derive probs from counts
  // uses build functions of CountRandLM and quantised stats.
  class StupidBackoffRandLM : public CountRandLM {
  public:
    StupidBackoffRandLM(RandLMInfo* info, Vocab* vocab) :
      CountRandLM(info, vocab), backoff_constant_(0),
      stupid_backoff_log10_(NULL),  corpus_size_log10_(0) {
      // make sure not storing histories
      assert(~(info->getEventType() & RandLMInfo::kHistoryEvent));
      // Check correct smoothing scheme
      assert(info->getSmoothingScheme() == RandLM::kStupidBackoffSmoothingCode);
    }
    StupidBackoffRandLM(RandLMInfo* info, RandLMFile* fin, int checks) :
      CountRandLM(info, fin, checks), backoff_constant_(0),
      stupid_backoff_log10_(NULL), corpus_size_log10_(0) {
      // make sure not storing histories
      assert(~(info->getEventType() & RandLMInfo::kHistoryEvent));
      // Check correct smoothing scheme
      assert(info->getSmoothingScheme() == RandLM::kStupidBackoffSmoothingCode);
      // init model (nothing to load from file)
      assert(initScheme());
    }
    ~StupidBackoffRandLM() {
      delete[] stupid_backoff_log10_;
    }
    // Implements stupid backoff smoothing
    float getProb(const WordID* ngram, int len, int* found, const void** state = 0);
  private:
    bool initScheme();
    float backoff_constant_;  // backoff weight is constant in stupid bo
    float* stupid_backoff_log10_;  // precompute backoff weight for different orders
    float corpus_size_log10_;  // used for unigram distribution
  };
  
  // WittenBellRandLM adds interface for storing "history" counts, i.e.
  // the number of distinct words that follow each distinct n-gram.
  // Implements specific build functions in order to store "history" counts.
  class WittenBellRandLM : public CountRandLM {
  public:
    WittenBellRandLM(RandLMInfo* info, Vocab* vocab) 
      : CountRandLM(info, vocab), num_histories_(NULL),
      zero_order_prob_(0), zero_backoff_(0), initial_term_(0),
      unigram_probs_(NULL), mle_probs_(NULL), 
      backoffs_(NULL), historyCodeCache_(NULL) {
      // check storing histories
      assert(info->getEventType() & RandLMInfo::kHistoryEvent);
      // check correct smoothing scheme
      assert(info->getSmoothingScheme() == RandLM::kWittenBellSmoothingCode);
      assert(initMembers());
    }
    WittenBellRandLM(RandLMInfo* info, RandLMFile* fin, int checks) 
      : CountRandLM(info, fin, checks), num_histories_(NULL),
      zero_order_prob_(0), zero_backoff_(0), initial_term_(0),
      unigram_probs_(NULL), mle_probs_(NULL), 
      backoffs_(NULL),  historyCodeCache_(NULL) {
      // check storing histories
      assert(info->getEventType() & RandLMInfo::kHistoryEvent);
      // check correct smoothing scheme
      assert(info->getSmoothingScheme() == RandLM::kWittenBellSmoothingCode);
      // load model
      assert(initMembers());
      assert(load(fin));
      assert(initScheme());  // compute and statistics that are not written to file
    }
    ~WittenBellRandLM() {
      delete[] num_histories_;
      delete[] unigram_probs_;
      // only instantiated from file
      if (mle_probs_ != NULL)
	for (int i = 0; i < max_codes_[kMainEventIdx]; ++i) {
	  delete[] mle_probs_[i];
	  delete[] backoffs_[i];
	}
      delete[] mle_probs_;
      delete[] backoffs_;
      delete historyCodeCache_;
    }
    // implements WittenBell smoothing (method C).
    float getProb(const WordID* ngram, int len, int* found, const void** state = 0);
    float getHistoryCount(const WordID* history, int len, int* found);
    bool clearCaches() {
      return probCache_->clearCache() && countCodeCache_->clearCache() 
	&& historyCodeCache_->clearCache();
    }
  private:
    bool initMembers();
    bool initScheme();
    virtual bool save(RandLMFile* fout);
    bool load(RandLMFile* fin);
    // includes count of ngram history
    bool storeNgram(const WordID* ngram, int len, Value value);
    uint64_t* num_histories_;  // number of histories stored in model
    float zero_order_prob_;
    float zero_backoff_;
    float initial_term_; 
    float* unigram_probs_;
    float** mle_probs_;
    float** backoffs_;
    RandLMCache<int>* historyCodeCache_;
  };
  
  // BackoffRandLM contains backoff data and implements interpolated backoff.
  class BackoffRandLM : public RandLM {
  public:
    BackoffRandLM(RandLMInfo* info, Vocab* vocab) :
      RandLM(info, vocab), log_prob_quantiser_(NULL),
      bo_quantiser_(NULL), num_boweights_(NULL), unk_log10prob_(-100),
      logProbCache_(NULL), boWeightCache_(NULL) {
      // check storing log probs not counts
      assert(info->getEventType() & RandLMInfo::kLogProbEvent
	     && info->getEventType() & RandLMInfo::kBackoffWeightEvent);
      assert(~(info->getEventType() & RandLMInfo::kAnyCountEvent));
      assert(initMembers());
    }
    BackoffRandLM(RandLMInfo* info, RandLMFile* fin, int checks) :
      RandLM(info, fin, checks), log_prob_quantiser_(NULL),
      bo_quantiser_(NULL), num_boweights_(NULL), unk_log10prob_(-100),
      logProbCache_(NULL), boWeightCache_(NULL) {
      // check storing log probs not counts
      assert(info->getEventType() & RandLMInfo::kLogProbEvent
	     && info->getEventType() & RandLMInfo::kBackoffWeightEvent);
      assert(~(info->getEventType() & RandLMInfo::kAnyCountEvent));
      assert(initMembers());
      // load model
      assert(load(fin));
    }
    virtual ~BackoffRandLM() {
      delete log_prob_quantiser_;
      delete bo_quantiser_;
      delete[] num_boweights_;
      delete logProbCache_;
      delete boWeightCache_;
    }
    // computes prob via generic backoff
    float getProb(const WordID* ngram, int len, int* found, const void** state);
    bool clearCaches() {
      return probCache_->clearCache() && logProbCache_->clearCache() 
	&& boWeightCache_->clearCache();
    }
  private:
    bool initMembers();
    virtual bool save(RandLMFile* fout);
    bool load(RandLMFile* fin);
    bool setupQuantisers(Stats* stats);
    bool setupMaxCodes();
    bool optimiseStruct(Stats* stats, float working_mem);
    bool storeNgram(const WordID* ngram, int len, Value value);
    UniformQuantiser* log_prob_quantiser_;  // quantises log-probs
    UniformQuantiser* bo_quantiser_;  // quantises bo-weights
    uint64_t* num_boweights_;  // number of backoff weights in model
    float unk_log10prob_;  // unk log prob
    RandLMCache<int>* logProbCache_;
    RandLMCache<int>* boWeightCache_;
  };

} // ends namespace
  
#endif  // INC_RANDLM_H
