// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <sstream>
#include "RandLMStats.h"
#include "RandLMPreproc.h"

namespace randlm{
  
  // static methods for creating statistics objects
  bool Stats::initStats(FileType input_type, int order, Stats*& stats) {
    // instantiate appropriate subclass given file type
    if (input_type == InputData::kCorpusFileType || input_type == InputData::kCountFileType)
      stats = new CountStats(order); 
    else if (input_type == InputData::kArpaFileType || input_type == InputData::kBackoffModelFileType)
      stats = new BackoffStats(order);
    return true;
  }
  // get statistics for this data
  bool Stats::getStats(Stats* stats, InputData* data) {
    // check whether stats were already estimated
    if (data->isCorpusData()) {
      Corpus* corpus = dynamic_cast<Corpus*>(data);
      assert(corpus != NULL);
      return getTokenStats(stats,corpus);
    }
    NgramFile* ngrams = dynamic_cast<NgramFile*>(data);
    assert(ngrams != NULL);
    return getNgramStats(stats, ngrams);
  }

  bool Stats::getTokenStats(Stats* stats, Corpus* corpus) {
    if (stats->hasTokenStats())
      return true;
    uint64_t tokens = corpus->getWordCount();
    stats->setTokenStats(tokens);
    return tokens > 0;
  }
  bool Stats::getNgramStats(Stats* stats, NgramFile* ngrams) {
    if (stats->hasNgramStats())
      return true;
    // check sort order
    assert(!(stats->requireSortedByNgram() && !ngrams->isSortedByNgram()));
    std::cerr << "Getting statistics from data ..." << std::endl;
    // start from top of file
    ngrams->reset();
    assert(stats->start());
    WordID ngram[RandLM::kMaxNgramOrder];
    int len;
    Value value;
    while (ngrams->nextEntry(&ngram[0], &len, &value))
      assert(stats->observe(&ngram[0], value, len));
    assert(stats->finish());
    ngrams->reset();
    return true;
  }

  bool Stats::init() {
    // set up structures to store counts of logprobs and backoff weights
    main_counts_.clear();
    aux_counts_.clear();
    total_main_ = 0;
    total_aux_ = 0;
    for (int i = 0; (i < max_order_) || (!order_specific_ && i <= max_order_); ++i) {
      main_counts_.push_back(FloatCounts());
      aux_counts_.push_back(FloatCounts());
    }
    return true;
  }

  // retrieve counts of EventType and order
  bool Stats::getCounts(FloatCounts & counts, EventType event, int order) {
    assert(estimated_); // check that finished estimation
    assert(hasStatsFor(event));
    assert(order >= 0 && order <= max_order_);
    assert(order_specific_ || order == 0);
    // retrieve only one set
    if (!order_specific_ || order > 0) {
      counts = event & main_event_ ? main_counts_[!order_specific_ ? 0 : order - 1]
	: aux_counts_[!order_specific_ ? 0 : order - 1];
    } else {
      // need to aggregate counts over all orders
      for (int i = 0; i < max_order_; ++i) {
	FloatCounts::iterator iter = event & main_event_ ? main_counts_[i].begin() 
	  : aux_counts_[i].begin();
	FloatCounts::iterator end = event & main_event_ ? main_counts_[i].end() 
	  : aux_counts_[i].end();
	while(iter != end) {
	  if (counts.count(iter->first) == 0)
	    counts[iter->first] = 0;
	  counts[iter->first] += iter->second;
	  ++iter;
	}
      }
    }
    return true;
  }
  
  // retrieve quantised counts of EventType and order
  bool Stats::getQuantisedCounts(Quantiser* quantiser, CodeCounts & quant_counts,
				 EventType event, int order) {
    assert(estimated_); // check that finished estimation
    assert(hasStatsFor(event));
    assert(order >= 0 && order <= max_order_);
    assert(order_specific_ || order == 0);
    assert(quantiser != NULL && quantiser->canQuantise(event));
    // retrieve only one set
    FloatCounts counts;
    assert(getCounts(counts, event, order));
    // iterate over value,freq quantising the values
    quant_counts.clear();
    uint64_t totalevents = 0;
    uint64_t totalcodes = 0;
    uint64_t totalcounts = 0;
    uint64_t maxcount = 0;
    for (FloatCounts::iterator iter = counts.begin(); iter != counts.end(); ++iter) {
      // special processing for history counts (since store history count - 1)
      if (event == RandLMInfo::kHistoryEvent)
	if (iter->first < 2)
	  continue;
      int code = event == RandLMInfo::kHistoryEvent ? quantiser->getCode(iter->first - 1) :
	quantiser->getCode(iter->first);
      if (quant_counts.count(code) == 0)
	quant_counts[code] = 0;
      quant_counts[code] += iter->second;
      totalevents += iter->second;
      totalcodes += code*iter->second;
      totalcounts += static_cast<uint64_t>(iter->first);
      if (iter->first > maxcount)
	maxcount = static_cast<uint64_t>(iter->first);
    }
    std::cerr << "Average code = " << static_cast<float>(totalcodes)/static_cast<float>(totalevents) 
	      << std::endl;
    std::cerr << "Average count = " << static_cast<float>(totalcounts)/static_cast<float>(totalevents) 
	      << std::endl;
    std::cerr << "Max count = " << maxcount << " (" << log(maxcount)/log(2.0) << ")" << std::endl;
    return true;
  }

  // i/o
  bool Stats::save(RandLMFile* statsout) {
    // write out statistics
    assert(estimated_);
    assert(statsout->write((char*)&max_order_, sizeof(max_order_)));
    assert(statsout->write((char*)&main_event_, sizeof(main_event_)));
    assert(statsout->write((char*)&aux_event_, sizeof(aux_event_)));
    assert(statsout->write((char*)&order_specific_, sizeof(order_specific_)));
    // for each ngram length
    for (int i = 0; i < (order_specific_ ? max_order_ : 1); ++i) {
      // for each type of event output the total number of stats and then the pairs
      for (int eventidx = 0; eventidx < 2; ++eventidx) { 
	FloatCounts these_counts = (eventidx == 0) ? main_counts_[i] : aux_counts_[i];
	size_t number = these_counts.size();
	EventType thistype = (eventidx == 0) ? main_event_ : aux_event_;
	assert(statsout->write((char*)&eventidx, sizeof(eventidx)));
	assert(statsout->write((char*)&thistype, sizeof(thistype)));
	assert(statsout->write((char*)&number, sizeof(number)));
	assert(statsout->write((char*)&i, sizeof(i)));
	for (FloatCounts::iterator iter = these_counts.begin(); 
	     iter != these_counts.end(); ++iter) {
	  assert(statsout->write((char*)&iter->first, sizeof(iter->first)));
	  assert(statsout->write((char*)&iter->second, sizeof(iter->second)));
	}
      }
    }
    // write out totals 
    assert(statsout->write((char*)&total_main_, sizeof(total_main_)));
    assert(statsout->write((char*)&total_aux_, sizeof(total_aux_)));
    return true;
  }

  bool Stats::load(RandLMFile* statsin) {
    // load stats file
    int order,main_event,aux_event;
    bool order_specific;
    // object parameters should match file
    assert(statsin->read((char*)&order, sizeof(max_order_)));
    assert(statsin->read((char*)&main_event, sizeof(main_event_)));
    assert(statsin->read((char*)&aux_event, sizeof(aux_event_)));
    assert(statsin->read((char*)&order_specific, sizeof(order_specific_)));
    assert(order >= max_order_);
    assert(static_cast<EventType>(main_event) == main_event_);
    assert(static_cast<EventType>(aux_event) == aux_event_);
    assert(order_specific_ == order_specific);
    // initalize structures
    assert(init());
    uint64_t total_main_check(0), total_aux_check(0); // use as check sum
    // load counts of values for each order unless not order_specific_
    // for each ngram length
    for (int i = 0; i < (order_specific_ ? max_order_ : 1); ++i) {
      // for each type of event output the total number of stats and then the pairs
      for (int eventidx = 0; eventidx < 2; ++eventidx) { 
	int this_order;
	size_t number;
	int thisidx;
	EventType thistype;
	assert(statsin->read((char*)&thisidx, sizeof(thisidx)));
	assert(thisidx == eventidx);
	assert(statsin->read((char*)&thistype, sizeof(thistype)));
	assert((thisidx == 0 && thistype == main_event_) ||
	       (thisidx == 1 && thistype == aux_event_));
	assert(statsin->read((char*)&number, sizeof(number)));
	assert(statsin->read((char*)&this_order, sizeof(this_order)));
	assert(this_order == i);
	for (size_t j = 0; j < number; ++j) {
	  float val(0);
	  uint64_t freq(0);
	  assert(statsin->read((char*)&val, sizeof(val)));
	  assert(statsin->read((char*)&freq, sizeof(freq)));
	  if (eventidx == 0) {
	    total_main_check += freq;
	    if (main_counts_[i].count(val) != 0) {
	      std::cerr << "duplicated main event: " << val << std::endl;
	      main_counts_[i][val] += freq;
	    } else {
	      main_counts_[i][val] = freq;
	    }
	  } else {
	    total_aux_check += freq;
	    if (aux_counts_[i].count(val) != 0) {
	      std::cerr << "duplicated aux event: " << val << std::endl;
	      aux_counts_[i][val] += freq;
	    } else {
	      aux_counts_[i][val] = freq;
	    }
	  }
	}
      }
    }
    // read totals 
    assert(statsin->read((char*)&total_main_, sizeof(total_main_)));
    assert(statsin->read((char*)&total_aux_, sizeof(total_aux_)));
    // check the sums
    assert(total_main_check == total_main_ && total_aux_check == total_aux_);
    estimated_ = true;
    return true;
  }  

  // class BackoffStats

  // doesn't need ngram details so just wrap simple function
  bool BackoffStats::observe(const Word* ngram, Value value, int len) {
    return observe(value, len);
  }
  bool BackoffStats::observe(const WordID* ngram, Value value, int len) {
    return observe(value, len);
  }
  // store the frequency of log probs and backoff weights
  bool BackoffStats::observe(Value value, int len) {
    if (estimated_)
      return false;
    assert(len > 0);
    assert(order_specific_ || len <= max_order_);
    // unpack logprob and backoff weight
    float logprob(0), bo_weight(0);
    assert(BackoffModelFile::convertFromValue(value, &logprob, &bo_weight));
    if (main_counts_[order_specific_ ? len - 1 : 0].count(logprob) == 0)
      main_counts_[order_specific_ ? len - 1 : 0][logprob] = 0;
    ++main_counts_[order_specific_ ? len - 1 : 0][logprob];
    ++total_main_;
    // not all ngrams have a backoff weight
    if (BackoffModelFile::ValidWeight(bo_weight)) {
      if (aux_counts_[order_specific_ ? len - 1 : 0].count(bo_weight) == 0)
	aux_counts_[order_specific_ ? len - 1 : 0][bo_weight] = 0;
      ++aux_counts_[order_specific_ ? len - 1 : 0][bo_weight];
      ++total_aux_;
    }
    return true;
  }

  // class CountStats stores statistics for ngram counts and histories
  bool CountStats::observe(const WordID* ngram, Value value, int len) {
    if (estimated_)
      return false;
    // but convert value to count and history
    assert(len > 0);
    assert(order_specific_ || len <= max_order_);
    float count(0),history(0);
    CountFile::convertFromValue(value, &count, &history);
    if (count > 0) {
      if (main_counts_[order_specific_ ? len - 1 : 0].count(count) == 0)
	main_counts_[order_specific_ ? len - 1 : 0][count] = 0;
      ++main_counts_[order_specific_ ? len - 1 : 0][count]; // count ngram
      ++total_main_;
    }
    if (history > 0) {
      if (aux_counts_[order_specific_ ? len - 1 : 0].count(history) == 0)
	aux_counts_[order_specific_ ? len - 1 : 0][history] = 0;
      ++aux_counts_[order_specific_ ? len - 1 : 0][history];
      ++total_aux_;
    }
    return true;
  }
  // store ngram count and if history has changed store that too
  bool CountStats::observe(const Word* ngram, Value value, int len) {
    if (estimated_)
      return false;
    // here value will only ever have a single float for the ngram count
    assert(len > 0);
    assert(order_specific_ || len <= max_order_);
    float count(0), history(0);
    CountFile::convertFromValue(value, &count, &history);
    ++main_counts_[order_specific_ ? len - 1 : 0][count]; // count ngram
    ++total_main_;
    // only count history for bigrams and up
    if (len < 2) 
      return true;
    // if first observation of this order then store history (i.e. n-1 gram)
    if (first_entry_[len - 1]) { 
      for (int i = 0; i < len - 1; ++i)
	this_history_[len - 1][i] = ngram[i];
      first_entry_[len - 1] = false;
      this_history_count_[len - 1] = 1;
      return true;
    }
    // determine whether the history is new and if so store count of counts
    bool same = true;
    int i = 0;
    while(same && (i < len - 1)){
      same &= (ngram[i] == this_history_[len - 1][i]);
      ++i;
    }
    // still same history so just increment current count
    if (same) { 
      ++this_history_count_[len - 1];
      return true;
    }
    // different history so store count of this history_count and reset history
    ++aux_counts_[order_specific_ ? len - 1 : 0][this_history_count_[len - 1]];
    ++total_aux_;
    for (int i = 0; i < len - 1; ++i)
      this_history_[len - 1][i] = ngram[i];
    this_history_count_[len - 1] = 1;
    return true;
  }
  // start estimation (setup structures for counting histories)
  bool CountStats::start() { 
    assert(init()); 
    estimated_ = false;
    for (int i = 0; i < RandLM::kMaxNgramOrder; ++i)
      first_entry_[i] = true;
    return true;
  }

  bool CountStats::finish() {
    // deal with final history counts that remain
    for (int i = 0; i < RandLM::kMaxNgramOrder; ++i) {
      if (!first_entry_[i]) {// if we observed some
	++aux_counts_[order_specific_ ? i : 0][this_history_count_[i]];
	++total_aux_;
      }
    }
    estimated_ = true;
    return true;
  }
}
