// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_LOG_FREQ_BLOOM_FILTER_H
#define INC_LOG_FREQ_BLOOM_FILTER_H

#include "RandLMStruct.h"
#include "RandLMHash.h"
#include "RandLMFilter.h"
#include "RandLMPreproc.h"

namespace randlm {
  // The LogFreqBloomFilter is described in Talbot and Osborne (ACL 2007).
  // Counts are quantised on a log-scale and stored as unary in a Bloom filter.
  // A constant expected error on this log-scale translates into a
  // constant expected relative error.
  class LogFreqBloomFilter : public virtual RandLMStruct {
  public:
    LogFreqBloomFilter(RandLMInfo* info) : RandLMStruct(info),
      filter_(NULL), m_(0), max_hashes_(NULL), hashes_(NULL), 
      alpha_(NULL), k_(NULL), unary_increments_(NULL),
      objects_(NULL), t_(0), inserted_(0), max_alpha_(0), max_k_(0), 
      max_cache_(0), used_(NULL), values_(NULL), stats_counters_(false) {
    }
    LogFreqBloomFilter(RandLMInfo* info, RandLMFile* fin) 
      : RandLMStruct(info, fin), filter_(NULL), m_(0), max_hashes_(NULL),
      hashes_(NULL), alpha_(NULL), k_(NULL), unary_increments_(NULL),
      objects_(NULL), t_(0), inserted_(0), max_alpha_(0), max_k_(0), 
      max_cache_(0), used_(NULL), values_(NULL), stats_counters_(false) {
      assert(load(fin));
      assert(setupCache(order_));
    }
    ~LogFreqBloomFilter() {
      delete filter_;
      for (int i = 0; i < num_events_; ++i) {
	for (int j = 0; j < max_hashes_[i]; ++j)
	  delete hashes_[i][j];
	delete[] hashes_[i];
      }
      delete[] max_hashes_;
      delete[] hashes_;
      delete[] alpha_;
      delete[] k_;
      if (unary_increments_ != NULL) {
	for (int i = 0; i < num_events_; ++i) {
	  delete[] unary_increments_[i];
	  delete[] objects_[i];
	}
	delete[] unary_increments_;
	delete[] objects_;
      }
      if (used_ != NULL) {
	for (int i = 0; i < num_events_; ++i) {
	  delete[] used_[i];
	  for (int j = 0; j < max_cache_; ++j)
	    delete[] values_[i][j];
	  delete[] values_[i];
	}
	delete[] used_;
	delete[] values_;
      }
    }
    // client functions
    bool insert(const WordID* ngram, int len, int event_idx, int code);
    bool query(const WordID* ngram, int len, int event_idx, int* code, int max);
    bool query(const WordID word, int start, int end, int event_idx, int* code, int max);
    // call be RandLM to determine the parameters
    virtual bool setCodeCounts(CodeCounts codes, uint64_t total, int event_idx, int order = 0);
    bool optimise(float working_mem);
    bool save(RandLMFile* fout);
    uint64_t getSize() { return m_; }
  protected:
    bool load(RandLMFile* fin);
    bool initStatsCounters();  // initialise structures prior to getting stats
    bool setupFilter();  // setup filter and hash functions
    bool setParameters();  // determine internal parameters based on error spec 
    bool inferParameters();  // determine internal parameters based on memory spec
    virtual int getMaxHashes(int event_idx); // determine total number of hashes
    virtual uint64_t computeTotalHashes();  // overridden by logfreq sketch
    virtual bool setupCache(int max_sequence);
    // member data 
    BitFilter* filter_;  // the filter itself (only ever one needed)
    uint64_t m_;  // size of bloom filter
    int* max_hashes_;  // per event idx
    UniversalHash<uint64_t>*** hashes_;  // hash functions per code and event
    int* alpha_;  // hashes set for a count of one
    int* k_;  // hashes set per log-incrmenet afterwards
    uint64_t** unary_increments_; // total number of increments on unary scale 
    uint64_t** objects_;  // total number of objects
    uint64_t t_;  // total hashes that will be performed
    uint64_t inserted_; 
    int max_alpha_; // per event idx
    int max_k_; // per event idx
    int max_cache_; // max sized sequence that can be cached
    // cache structures
    int** used_;  // idx of previously used hash function
    uint64_t*** values_;  // values
    bool stats_counters_; //whether instantiated stat counters
  };
}
#endif  // INC_LOG_FREQ_BLOOM_FILTER_H
