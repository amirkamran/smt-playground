// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <sstream>
#include "RandLMVocab.h"

namespace randlm {

  // Vocab class
  const WordID Vocab::kMaxWordID;
  const WordID Vocab::kOOVWordID;
  const WordID Vocab::kBOSWordID;
  const Word Vocab::kBOS = "<s>";
  const Word Vocab::kEOS = "</s>";
  const Word Vocab::kOOVWord = "<unk>";
    
  WordID Vocab::getWordID(const Word & word) {
    // get id and possibly add to vocab 
    if (words2ids_.find(word) == words2ids_.end()) {
      if (!closed_ && word != Vocab::kOOVWord) {
	assert(words2ids_.size() < Vocab::kMaxWordID);
	words2ids_[word] = words2ids_.size(); // size() returns size AFTER insertion of word
	ids2words_[words2ids_.size()] = word; // so size() is the same here ... 
      } else {
	return Vocab::kOOVWordID;
      }
    }
    WordID id = words2ids_[word];
    return id;
  }
    
  Word Vocab::getWord(WordID id) {
    // get word string given id
    return (ids2words_.find(id) == ids2words_.end()) ? Vocab::kOOVWord : ids2words_[id];
  }
  
  bool Vocab::inVocab(WordID id) {
    return ids2words_.find(id) != ids2words_.end();
  }

  bool Vocab::inVocab(const Word & word) {
    return words2ids_.find(word) != words2ids_.end();
  }
  
  bool Vocab::save(const std::string & vocab_path) {
    // save vocab as id -> word 
    RandLMFile vcbout(vocab_path, std::ios::out);
    return save(&vcbout);
  }
  bool Vocab::save(RandLMFile* vcbout) {
    // then each vcb entry
    *vcbout << ids2words_.size() << "\n";
    iterate(ids2words_, iter)
      *vcbout << iter->second << "\t" << iter->first << "\n";
    return true;
  }
  
  bool Vocab::load(const std::string & vocab_path, bool closed) {
    RandLMFile vcbin(vocab_path, std::ios::in);
    std::cerr << "Loading vocab from " << vocab_path << std::endl;
    return load(&vcbin, closed);
  }
  bool Vocab::load(RandLMFile* vcbin, bool closed) {
    // load vocab id -> word mapping 
    words2ids_.clear();  // reset mapping
    ids2words_.clear();
    std::string line;
    Word word;
    WordID id;
    assert(getline(*vcbin, line));
    std::istringstream first(line.c_str());
    uint32_t vcbsize(0);
    first >> vcbsize;
    uint32_t loadedsize = 0;
    while (loadedsize++ < vcbsize && getline(*vcbin, line)) {
      std::istringstream entry(line.c_str());
      entry >> word;
      entry >> id; 
      // may be no id (i.e. file may just be a word list)
      if (id == 0 && word != Vocab::kOOVWord) 
	id = ids2words_.size() + 1;  // assign ids sequentially starting from 1
      assert(ids2words_.count(id) == 0 && words2ids_.count(word) == 0);
      ids2words_[id] = word;
      words2ids_[word] = id;
    }
    closed_ = closed;  // once loaded fix vocab ?
    std::cerr << "Loaded vocab with " << ids2words_.size() << " words." << std::endl;
    return true;
  }
  void Vocab::printVocab() {
    iterate(ids2words_, iter)
      std::cerr << iter->second << "\t" << iter->first << "\n";
  }

}
