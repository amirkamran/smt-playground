// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_BUILDER_H
#define INC_RANDLM_BUILDER_H

#include "RandLMParams.h"
#include "RandLMPipelineTool.h"
#include "RandLM.h"

// Class RandLMBuilder manages the construction of a RandLM 

namespace randlm {

  class RandLMBuilder : public RandLMPipelineTool {
  public:
    const static std::string kBuilder;    
    RandLMBuilder(RandLMParams* params) : RandLMPipelineTool(params) {
      info_ = NULL;
      randlm_ = NULL;
      // check for parameters required to specify a RandLM 
      assert(checkParams(kBuilder));
    }
    ~RandLMBuilder() { 
      delete info_;
      delete randlm_; 
    }
    bool preprocess();  // preprocesses data to serve as input to RandLM
    bool build();  // constructs RandLM from processed data
    bool getRandLM(RandLM*& randlm);
  private:
    bool getConfiguration(StructCode* code, Smoothing* scheme, 
			  Estimator* estimator, EventType* events);
    bool setupInfo();
    bool setRequirements();
    bool setDefaultValues();
    std::string getStructPath();
    RandLMInfo* info_;
    RandLM* randlm_;
  };
}

#endif  // INC_RANDLM_BUILDER_H
