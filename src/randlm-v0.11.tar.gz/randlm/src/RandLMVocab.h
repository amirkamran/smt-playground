// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_VOCAB_H
#define INC_RANDLM_VOCAB_H

#include <map>
#include <string>
#include "RandLMTypes.h"
#include "RandLMFile.h"

namespace randlm {
  // Vocab maps between strings and uint32 ids.

  class Vocab {
  public:
    static const WordID kMaxWordID = (1ull << 31) - 1; 
    static const WordID kOOVWordID = 0;   // out of vocabulary word id
    static const WordID kBOSWordID = 1;
    static const Word kBOS;  // beginning of sentence marker
    static const Word kEOS;  // end of sentence marker
    static const Word kOOVWord;  // <unk>
    Vocab() : closed_(false) {
      getWordID(kBOS);  // added in case not observed in corpus
      getWordID(kEOS);
    }  // if no file then must allow new words
    // specify whether more words can be added via 'closed'
    // assume that if a vocab is loaded from file then it should be closed.
    Vocab(const std::string & vocab_path, bool closed = true) {
      assert(load(vocab_path, closed));  
    }
    Vocab(RandLMFile* fin, bool closed = true) {
      assert(load(fin, closed));  
    }
    ~Vocab() {}
    WordID getWordID(const Word & word);
    bool inVocab(WordID id);
    bool inVocab(const Word & word);
    Word getWord(WordID id);
    uint32_t getVocabSize() { return words2ids_.size(); }
    void makeClosed() { closed_ = true; }
    void makeOpen() { closed_ = false; }
    bool isClosed() { return closed_; }
    bool save(const std::string & vocab_path);
    bool save(RandLMFile* fout);
    bool load(const std::string & vocab_path, bool closed = true);
    bool load(RandLMFile* fin, bool closed = true);
    void printVocab();
    std::map<Word, WordID>::const_iterator vocabStart() {
      return words2ids_.begin();
    }
    std::map<Word, WordID>::const_iterator vocabEnd() {
      return words2ids_.end();
    }
  private:
    std::map<Word, WordID> words2ids_;  // map from strings to word ids
    std::map<WordID, Word> ids2words_;  // map from ids to strings
    bool closed_;  // can more words be added
  };
}

#endif // INC_RANDLM_VOCAB_H
