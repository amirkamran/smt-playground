// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <stack>
#include <numeric>
#include "BloomMap.h"

namespace randlm {

  const int Node::kRootHeight;
  const uint64_t Node::kOffsetMask;

  bool BloomMap::printCounters(int event_idx, int len) {
    std::cerr << "Checking stats counters for " << event_idx << " , " << len << std::endl;
    std::map<int, uint64_t> counts = counters_[event_idx][len];
    for (std::map<int, uint64_t>::const_iterator iter = counts.begin(); iter != counts.end(); ++iter)
      if (iter->second > 0)
	std::cerr << iter->first << " " << iter->second << std::endl;
    return true;
  }
  bool BloomMap::insert(const WordID* ngram, int len, int event_idx, int code) {
    assert(code >= 0 && code <= max_code_[event_idx]);
    // check we're storing what we specified in setCodeCounts
    if (counters_[event_idx][order_specific_ ? len - 1 : 0][code] > 0)
      --counters_[event_idx][order_specific_ ? len - 1 : 0][code];
    else 
      std::cerr << "extra code: " << event_idx << ", " << (order_specific_ ? len - 1 : 0) 
		<< ", " << code << std::endl;
    // get path from lookup table
    uint64_t path = code_to_leaf_[event_idx][code];
    // follow path and insert to filter
    int idx = 0;
    Node* node = root_[event_idx];
    while (true) {
      assert(node != NULL);
      int num_hashes = (node->right_ == NULL) ? alpha_[len - 1] : k_[len - 1];  // leaf or internal node
      int i = 0;
      while (i < num_hashes) {
	assert(filter_->setBit(hashes_[event_idx][idx + i]->hash(ngram, len) + node->offset_));
	++i;
      }
      if (node->right_ == NULL) { // finished leaf
	idx += num_hashes;
	break;
      }
      // right branch by 1 in path to leaf
      node = (path & (1ull << node->height_)) ? node->right_ : node->left_;
      idx += num_hashes;
    }
    inserted_ += idx;
    return t_ >= inserted_;
  }

  bool BloomMap::query(const WordID* ngram, int len, int event_idx, int* code, int max) {
    // map from codes to leaf ids some codes may not be present so |leaves| <= |codes|
    uint64_t max_leaf = max < max_code_[event_idx] ? code_to_leaf_[event_idx][max] : Node::kOffsetMask;
    // deal with root node first
    int idx = 0;  // hash index
    int cached = 0;  // index cached values
    std::stack<Node*> unexplored;  // stores left branches not taken immediately
    Node* node = root_[event_idx]; // start at root
    *code = kNullCode;
    while (true) { 
      int num_hashes = (node->right_ == NULL) ? alpha_[len - 1] : k_[len - 1];  // leaf or internal node
      int i = 0;
      while (i < num_hashes) {   // test this node
	if (idx + i >= cached) { // base hashes cached
	  assert(hashes_[event_idx][idx + i]->hash(ngram, len, &values_[event_idx][len - 1][idx + i])); 
	  ++cached;
	}
	// test with base hash + offset
	if (!filter_->testBit(values_[event_idx][len-1][idx + i] + node->offset_))
	  break;
	++i;
      }
      if (i == num_hashes) { // node was successfull
	if (node->right_ == NULL) { // leaf node so return code
	  *code = node->code_;
	  return true;
	}
	// internal node so descend to next level
	idx += num_hashes; // update hash index
	// if bound applies ignore right child
	if (node->right_->offset_ > max_leaf) {
	  node = node->left_;
	} else {
	  // otherwise follow right child but store left child on stack
	  node->left_->hash_idx_ = idx; // remember hash index for back tracking
	  unexplored.push(node->left_); 
	  node = node->right_;
	}
      } else { // failed at current node so back track
	if (unexplored.empty()) { // if no more paths to explore then fail
	  *code = kNullCode;
	  return false;  
	}
	node = unexplored.top();
	unexplored.pop();
	idx = node->hash_idx_; // reset hash index
      }
    }
    assert(false); // shouldn't get here ...
    return false;
  }

  // Note: this function does two layers of caching --- base hash functions are cached
  // and these themselves are incrementally computed from lower order base hashes.
  bool BloomMap::query(const WordID word, int start, int end, int event_idx, int* code,  int max) {
    // map from codes to leaf ids some codes may not be present so |leaves| <= |codes|
    //std::cerr <<"q:" << event_idx << " " << start << " " << end << " " << max;
    uint64_t max_leaf = max < max_code_[event_idx] ? code_to_leaf_[event_idx][max] : Node::kOffsetMask;
    // deal with root node first
    int idx = 0;  // hash index
    int cached = 0; // number of base hash functions cached for this word
    std::stack<Node*> unexplored;  // stores left branches not taken immediately
    Node* node = root_[event_idx]; // start at root
    // unigram so refresh cached
    if (start == end)
      used_[event_idx][end] = 0;  // number of 'base' hash functions used
    *code = kNullCode;
    while (true) { 
      int num_hashes = (node->right_ == NULL) ? alpha_[end - start] : k_[end - start];  // leaf or internal node
      int i = 0;
      while (i < num_hashes) {   // test this node
	// exceeded lowest point in tree for this code so far
	if (idx + i >= cached) {
	  // unigram so initialise
	  if (start == end) // hash values have been cached for all lower order ngrams
	    values_[event_idx][end][idx + i] = 0;
	  else {
	    assert(used_[event_idx][end] > idx + i);
	  }
	  // increment base hash
	  assert(hashes_[event_idx][idx + i]->increment(word, end - start,
							values_[event_idx][end][idx + i],
							&values_[event_idx][end][idx + i])); 
	  ++cached;
	}
	// test filter with base + offset
	if (!filter_->testBit(values_[event_idx][end][idx + i] + node->offset_))
	  break;
	++i;
      }
      if (i == num_hashes) { // node was successfull
	if (node->right_ == NULL) { // leaf node so return code
	  *code = node->code_;
	  // cache any hashes that may be used by ngrams with
	  // codes <= code (only happens if lower codes have longer paths). 
	  while (cached < alpha_[end - start] + (k_[end - start] * code_to_bound_[event_idx][*code])) {
	    if (start == end) {
	      values_[event_idx][end][cached] = 0;
	    } else { // we can assume that values have been cached for all subngrams found
	      assert(used_[event_idx][end] > idx + i);
	    }
	    // increment base hash
	    assert(hashes_[event_idx][cached]->increment(word, end - start, values_[event_idx][end][cached],
							 &values_[event_idx][end][cached]));
	    ++cached;
	  }
	  used_[event_idx][end] = cached;
	  return true;
	}
	// internal node so descend to next level
	idx += num_hashes; // update hash index
	// if bound applies ignore right child
	if (node->right_->offset_ > max_leaf) {
	  node = node->left_;
	} else {
	  // otherwise follow right child but store left child on stack
	  node->left_->hash_idx_ = idx; // remember hash index for back tracking
	  unexplored.push(node->left_); 
	  node = node->right_;
	}
      } else { // failed at current node so back track
	if (unexplored.empty()) {// if no more paths to explore then fail
	  used_[event_idx][end] = 0;
	  return false;  
	}
	node = unexplored.top();
	unexplored.pop();
	idx = node->hash_idx_; // reset hash index
      }
    }
    assert(false); // shouldn't get here!
    return false;
  }

  bool BloomMap::setCodeCounts(CodeCounts codes, uint64_t total, int event_idx, int order) {
    // store complete counts
    int thisorder = order_specific_ ? order - 1 : 0;
    assert(thisorder >= 0 && thisorder < order_);
    if (counters_.count(event_idx) == 0)
      counters_[event_idx] = std::map<int, std::map<int, uint64_t> >();
    if (counters_[event_idx].count(thisorder))
      counters_[event_idx][thisorder] = std::map<int, uint64_t>();
    for (CodeCounts::iterator iter = codes.begin(); iter != codes.end(); ++iter) {
      int code = iter->first;
      uint64_t freq = iter->second;
      if (counters_[event_idx][thisorder].count(code) == 0)
	counters_[event_idx][thisorder][code] = 0;
      counters_[event_idx][thisorder][code] += freq;
      max_code_[event_idx] = code > max_code_[event_idx] ? code : max_code_[event_idx];
      min_code_[event_idx] = code < min_code_[event_idx] ? code : min_code_[event_idx];
    }
    stats_counters_ = true;
    return true; 
  }

  bool BloomMap::optimise(float working_mem) {
    assert(!optimised_);  // only call once
    // optimise error/space 
    assert(info_ != NULL);
    assert(info_->hasFalsePosSpec());
    assert(!(info_->hasFalseNegSpec() || info_->hasMemorySpec()));
    assert(setParameters()); // from LogFreqBF
    assert(computePaths());
    assert(setupCodingTree());
    assert(setupFilter());  // from LogFreqBF
    optimised_ = true;
    return true;
  }

  int BloomMap::getMaxHashes(int event_idx) {
    // determine max path length
    assert(max_hashes_[event_idx] == 0 && max_code_[event_idx] >= 0);
    assert(max_alpha_ > 0 && max_k_ > 0);
    assert(code_to_path_len_ != NULL && code_to_path_len_[event_idx] != NULL);
    std::cerr << "Max alpha = " << max_alpha_ << " max k = " << max_k_ << std::endl;
    int max_path_len = 0;
    for (int j = 0; j <= max_code_[event_idx]; ++j) 
      max_path_len = code_to_path_len_[event_idx][j] > max_path_len 
	? code_to_path_len_[event_idx][j] : max_path_len;
    std::cerr << "Max path len = " << max_path_len << std::endl;
    int max_hashes = (max_path_len * max_k_) + max_alpha_;
    std::cerr << "Max hashes = " << max_hashes << std::endl;
    return max_hashes;
  }

  uint64_t BloomMap::computeTotalHashes() {
    // each code has different number of hashes
    assert(root_ != NULL && code_to_path_len_ != NULL);
    uint64_t total = 0;
    for (int i = 0; i < num_events_; ++i) {
      assert(counters_.count(i) != 0);
      for (int j = 0; j < (order_specific_ ? order_ : 1); ++j) {
	if (counters_[i].count(j) > 0) {
	  for (std::map<int, uint64_t>::const_iterator iter = counters_[i][j].begin(); 
	       iter != counters_[i][j].end(); ++iter) {
	    int code = iter->first;
	    uint64_t freq = iter->second;
	    // path length constant across ngram orders but may use different num hashes per node
	    total += freq * static_cast<uint64_t>(alpha_[j] + (code_to_path_len_[i][code] * k_[j]));
	  }
	}
      }
    }
    return total;
  }
  
  bool BloomMap::computePaths() {
    // determine the path lengths based on distribution for codes of each type
    assert(stats_counters_ && root_ == NULL && max_code_ > 0);
    code_to_leaf_ = new uint64_t*[num_events_];
    code_to_path_len_ = new int*[num_events_];
    code_to_bound_ = new int*[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      code_to_leaf_[i] = new uint64_t[max_code_[i] + 1];
      code_to_path_len_[i] = new int[max_code_[i] + 1];
      code_to_bound_[i] = new int[max_code_[i] + 1];
      assert(counters_.count(i) != 0);
      // compute totals per code across all order ngrams
      std::map<int, uint64_t> code_totals;
      for (std::map<int, std::map<int, uint64_t> >::const_iterator iter = counters_[i].begin();
	   iter != counters_[i].end(); ++iter)
	for (std::map<int, uint64_t>::const_iterator iter2 = iter->second.begin(); 
	     iter2 != iter->second.end(); ++iter2) {
	  if (code_totals.count(iter2->first) == 0)
	    code_totals[iter2->first] = 0;
	  code_totals[iter2->first] += iter2->second;
	}
      // compute grand total for all codes
      uint64_t total = 0;
      for (std::map<int, uint64_t>::const_iterator iter = code_totals.begin(); 
	   iter != code_totals.end(); ++iter)
	total += iter->second; // frequencies
      // normalise code counts to probabilities
      std::map<int, double> code_probs;
      for (std::map<int, uint64_t>::const_iterator iter = code_totals.begin();
	   iter != code_totals.end(); ++iter)
	code_probs[iter->first] = static_cast<double>(iter->second) / static_cast<double>(total);
      // apply Knuth algorithm for near-optimal alphabetic binary tree
      std::map<int, std::pair<double, std::pair<uint64_t, int> > > qs;
      for (std::map<int, double>::const_iterator iter = code_probs.begin(); 
	   iter != code_probs.end(); ++iter) {
	double weight = iter->second / 2.0;
	for (std::map<int, double>::const_iterator iter2 = code_probs.begin(); 
	     iter2 != iter; ++iter2)
	  weight += code_probs[iter2->first];
	qs[iter->first] = std::make_pair(weight, std::make_pair(0ull, 0));
      }
      // determine shortest set of differentiating binary fractions
      std::map<int, std::pair<uint64_t, int> > paths;
      if (qs.size() > 0) { // not a good constraint
	if (qs.size() == 1) {
	  //assert(max_code_[i] == 0);
	  paths[0] = std::make_pair(1ull, 1);
	} else {
	  assert(partitionCodes(qs, 1, paths));
	}
      }	
      // save paths and lens filling in missing codes with previous leaf
      uint64_t lastleaf = 0;
      int leaves = 0;
      int len_bound = 0;
      for (int c = 0; c <= max_code_[i]; ++c) {
	if (paths.count(c)) { 
	  lastleaf = paths[c].first; 
	  len_bound = (paths[c].second > len_bound) ? paths[c].second : len_bound;
	  ++leaves;
	  code_to_path_len_[i][c] = paths[c].second;
	} else {
	  code_to_path_len_[i][c] = 0;   // zero len implies unused code
	}
	code_to_leaf_[i][c] = lastleaf;
	code_to_bound_[i][c] = len_bound; // longest path so far
      }
      std::cerr << "Binary tree will have " << leaves << " leaves." << std::endl;
    }
    return true;
  }

  bool BloomMap::partitionCodes(std::map<int, std::pair<double, std::pair<uint64_t, int> > > &qs, 
				int depth, std::map<int, std::pair<uint64_t, int> > &paths) {
    assert(qs.size() > 1 && depth <= Node::kRootHeight && depth >= 0);
    // split codes based on digit in binary fraction
    // adjust threshold until some actual split takes place
    while (true) {
      int rcount = 0; 
      int lcount = 0;
      for (std::map<int, std::pair<double, std::pair<uint64_t, int> > >::const_iterator iter = qs.begin();
	   iter != qs.end(); ++iter) {
	if ((iter->second).first > 1.0/static_cast<double>(1ull << depth))
	  ++rcount;
	else
	  ++lcount;
      }
      // if no split then adjust threshold
      if (rcount == 0) {
	++depth;
      } else if (lcount == 0) {
	for(std::map<int, std::pair<double, std::pair<uint64_t, int> > >::iterator iter = qs.begin();
	    iter != qs.end(); ++iter)
	  (iter->second).first -= 1.0/static_cast<double>(1ull << depth);
      } else {
	break;
      }
    }
    // update to reflect split and recurse
    std::map<int, std::pair<double, std::pair<uint64_t, int> > > left;
    std::map<int, std::pair<double, std::pair<uint64_t, int> > > right;
    for (std::map<int, std::pair<double, std::pair<uint64_t, int> > >::const_iterator iter = qs.begin();
	 iter != qs.end(); ++iter) {
      double weight = (iter->second).first;
      uint64_t path = (iter->second).second.first;
      int len = (iter->second).second.second;
      if ((iter->second).first > 1.0/static_cast<double>(1ull << depth)) {
	weight -= 1.0/static_cast<double>(1ull << depth);
	path |= (1ull << (Node::kRootHeight - len));
	++len;
	right[iter->first] = std::make_pair(weight, std::make_pair(path, len));
      } else {
	++len;
	left[iter->first] = std::make_pair(weight, std::make_pair(path, len));
      }
    }
    // if finished store complete paths and lengths
    if (left.size() == 1)
      paths[left.begin()->first] = left.begin()->second.second;
    else
      assert(partitionCodes(left, depth + 1, paths));
    if (right.size() == 1)
      paths[right.begin()->first] = right.begin()->second.second;      
    else
      assert(partitionCodes(right, depth + 1, paths));
    return true;
  } 

  bool BloomMap::setupCodingTree() {
    // uses paths to instantiate a tree
    assert(root_ == NULL && code_to_leaf_ != NULL);
    root_ = new Node*[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      root_[i] = new Node(0ull, Node::kRootHeight);
      for (int j = 0; j <= max_code_[i]; ++j) {
	if (code_to_path_len_[i][j] == 0) //no path to add
	  continue; 
	assert(addPath(j, code_to_leaf_[i][j], code_to_path_len_[i][j], root_[i]));
      }
      std::cerr << "Setup binary tree." <<std::endl;
    }

    return true;
  }

  bool BloomMap::addPath(int code, uint64_t path, int len, Node* node) {
    // add paths recursively
    if (len == (Node::kRootHeight - node->height_)) {
      node->code_ = code;
      return true;
    }
    if (path & (1ull << node->height_)) {
      if (node->right_ == NULL) 
	node->right_ = new Node(path & (Node::kOffsetMask << node->height_), node->height_ - 1);
      return addPath(code, path, len, node->right_);
    } else {
      if (node->left_ == NULL)
	node->left_ = new Node(path & (Node::kOffsetMask << node->height_), node->height_ - 1);
      return addPath(code, path, len, node->left_);
    }
    return false;  // never get here
  }

  bool BloomMap::load(RandLMFile* fin) {
    // load in details of code -> path mapping
    assert(code_to_leaf_ == NULL && code_to_path_len_ == NULL);
    code_to_leaf_ = new uint64_t*[num_events_];
    code_to_path_len_ = new int*[num_events_];
    code_to_bound_ = new int*[num_events_];
    for (int i = 0; i < num_events_; ++i) {
      code_to_leaf_[i] = new uint64_t[max_code_[i] + 1];
      code_to_path_len_[i] = new int[max_code_[i] + 1];
      code_to_bound_[i] = new int[max_code_[i] + 1];
      std::cerr << "Loading " << max_code_[i] + 1 << " paths." <<std::endl;
      for (int j = 0; j <= max_code_[i]; ++j) {
	assert(fin->read((char*)&code_to_leaf_[i][j], sizeof(code_to_leaf_[i][j])));
	assert(fin->read((char*)&code_to_path_len_[i][j], sizeof(code_to_path_len_[i][j])));
	assert(fin->read((char*)&code_to_bound_[i][j], sizeof(code_to_bound_[i][j])));
      }
    }
    assert(setupCodingTree());
    return true;
  }

  bool BloomMap::save(RandLMFile* fout) {
    assert(fout != NULL && LogFreqBloomFilter::save(fout));
    // save code paths
    assert(code_to_leaf_ != NULL && code_to_path_len_ != NULL);
    for (int i = 0; i < num_events_; ++i) {
      assert(max_code_[i] >= 0);
      for (int j = 0; j <= max_code_[i]; ++j) {
	assert(fout->write((char*)&code_to_leaf_[i][j], sizeof(code_to_leaf_[i][j])));
	assert(fout->write((char*)&code_to_path_len_[i][j], sizeof(code_to_path_len_[i][j])));
	assert(fout->write((char*)&code_to_bound_[i][j], sizeof(code_to_bound_[i][j])));
      }
      std::cerr << "Saved " << max_code_[i] + 1 << " paths." <<std::endl;
    }
    return true;
  }

  // debugging
  bool BloomMap::printID(uint64_t id) {
    std::cerr << id << " :\t";
    for (int i = 63; i > 32; --i)
      if (id & (1ull << i))
	std::cerr << 1;
      else
	std::cerr << 0;
    std::cerr << std::endl;
    return true;
  }
  
}
