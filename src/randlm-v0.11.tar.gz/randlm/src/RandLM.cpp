// Copyright 2008 David Talbot
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#include <cmath>
#include <algorithm>
#include "RandLM.h"
#include "RandLMPreproc.h"
#include "RandLMVocab.h"
#include "RandLMStats.h"
#include "RandLMQuantiser.h"
#include "RandLMStruct.h"
#include "BloomMap.h"

namespace randlm {

  // generic randomised language model class
  const std::string RandLM::kNullSmoothing = "__NULL__";
  const std::string RandLM::kStupidBackoffSmoothing = "StupidBackoff";
  const std::string RandLM::kWittenBellSmoothing = "WittenBell";  
  const std::string RandLM::kBackoffSmoothing = "Backoff";  
  const std::string RandLM::kRandLMFileType = "randlm";

  const int RandLM::kNullSmoothingCode;
  const int RandLM::kStupidBackoffSmoothingCode;
  const int RandLM::kWittenBellSmoothingCode;
  const int RandLM::kBackoffSmoothingCode;

  const float RandLM::kNullLogProb;
  const float RandLM::kUnknownLogProb;
  
  const int RandLM::kMainEventIdx;
  const int RandLM::kAuxEventIdx;

  const int RandLM::kNoChecks;
  const int RandLM::kStandardChecks;
  const int RandLM::kAllChecks;

  bool RandLM::getSmoothingCode(const std::string & smoothing_name, int* smoothing_code) {
    *smoothing_code = kNullSmoothingCode;
    if (smoothing_name == kStupidBackoffSmoothing)
      *smoothing_code = kStupidBackoffSmoothingCode;
    else if (smoothing_name == kWittenBellSmoothing)
      *smoothing_code = kWittenBellSmoothingCode;
    else if (smoothing_name == kBackoffSmoothing)
      *smoothing_code = kBackoffSmoothingCode;
    return *smoothing_code != kNullSmoothingCode;
  }

  std::string RandLM::getSmoothingName(int smoothing_code) {
    std::string smoothing_name = kNullSmoothing;
    switch (smoothing_code) {
    case kStupidBackoffSmoothingCode:
      smoothing_name = kStupidBackoffSmoothing;
      break;
    case kWittenBellSmoothingCode:
      smoothing_name == kWittenBellSmoothing;
      break;
    case  kBackoffSmoothingCode:
      smoothing_name = kBackoffSmoothing;
      break;
    }
    return smoothing_name;
  }
  
  bool RandLM::getDefaultSmoothing(StructCode code, FileType input_type, Estimator estimator,
				   Smoothing* scheme) {
    // If data is backoff probs then use that scheme
    *scheme = kNullSmoothingCode;
    if (input_type == InputData::kBackoffModelFileType 
	|| input_type == InputData::kArpaFileType)
      *scheme = kBackoffSmoothingCode;
    else  // use stupid backoff as default 
      *scheme = kStupidBackoffSmoothingCode;
    return *scheme != kNullSmoothingCode;
  }

  bool RandLM::getRequiredEventType(Smoothing scheme, EventType* events) {
    // Determine what events we'll need statistics on for this smoothing scheme
    *events = RandLMInfo::kNullEvent;
    switch (scheme) {
    case RandLM::kWittenBellSmoothingCode:
      *events = RandLMInfo::kHistoryEvent;
    case RandLM::kStupidBackoffSmoothingCode:
      *events |= RandLMInfo::kCountEvent;
      break;
    case RandLM::kBackoffSmoothingCode:
      *events = RandLMInfo::kLogProbEvent | RandLMInfo::kBackoffWeightEvent;
      break;
    }
    return *events != RandLMInfo::kNullEvent;
  }

  bool RandLM::getInputRequirements(RandLMInfo* info, FileType inputType, Format inputFormat,
				    FileType* requiredInputType, Format* requiredInputFormat) {
    // determine appropriate formatting for specifications and input data (fail if none possible)
    assert(info != NULL);
    switch (info->getStructType()) {
    case RandLMStruct::kLogFreqBloomFilterCode:
      // can only store counts
      *requiredInputType = InputData::kCountFileType;
      *requiredInputFormat = inputFormat;
      // Witten Bell smoothing requires sorted ngrams to count histories on the fly.
      if (info->getSmoothingScheme() == RandLM::kWittenBellSmoothingCode)
	*requiredInputFormat = (inputFormat & ~InputData::kSortedByValueFormat)  
	  | InputData::kSortedByNgramFormat;
      break;
    case RandLMStruct::kLogFreqSketchCode:
    case RandLMStruct::kCountMinSketchCode:
      // need to process the corpus directly
      *requiredInputType = InputData::kCorpusFileType;
      *requiredInputFormat = inputFormat;  // none
      break;
    case RandLMStruct::kBloomMapCode:
      *requiredInputFormat = inputFormat;  // none
      // Witten Bell smoothing requires sorted ngrams to count histories on the fly.
      if (info->getSmoothingScheme() == RandLM::kWittenBellSmoothingCode)
	*requiredInputFormat = (inputFormat & ~InputData::kSortedByValueFormat)
	  | InputData::kSortedByNgramFormat;
      // can store counts or back off model directly
      if (inputType == InputData::kCorpusFileType || inputType == InputData::kCountFileType)
	*requiredInputType = InputData::kCountFileType;
      else if (inputType == InputData::kArpaFileType || inputType == InputData::kBackoffModelFileType)
	*requiredInputType = InputData::kBackoffModelFileType;
      break;
    case  RandLMStruct::kBloomierFilterCode:
      // Witten Bell smoothing requires sorted ngrams to count histories on the fly.
      assert(info->getSmoothingScheme() != RandLM::kWittenBellSmoothingCode);
      // can store counts or back off model directly formatting is identical
      *requiredInputFormat = (inputFormat & ~InputData::kSortedByValueFormat)
	| InputData::kSortedByNgramFormat | InputData::kReversedNgramsFormat 
	| InputData::kIntegerisedFormat;
      if(inputType == InputData::kCorpusFileType || inputType == InputData::kCountFileType)
	*requiredInputType = InputData::kCountFileType;
      else if (inputType == InputData::kArpaFileType || inputType == InputData::kBackoffModelFileType)
	*requiredInputType = InputData::kBackoffModelFileType;
      break;
    case RandLMStruct::kLossyDictCode:
      // Witten Bell smoothing requires sorted ngrams to count histories on the fly.
      assert(info->getSmoothingScheme() != RandLM::kWittenBellSmoothingCode);
      // can store counts or backoff model formatting is identical
      *requiredInputFormat = (inputFormat & ~InputData::kSortedByNgramFormat)
	| InputData::kSortedByValueFormat;
      if (inputType == InputData::kCorpusFileType || inputType == InputData::kCountFileType)
	*requiredInputType = InputData::kCountFileType;
      else if (inputType == InputData::kArpaFileType || inputType == InputData::kBackoffModelFileType)
	*requiredInputType = InputData::kBackoffModelFileType;
      break;
    }
    return true;
  }
  // used by client to build from file
  RandLM* RandLM::initRandLM(const std::string& filename, int order, int cache_size) {
    // reads alpha and checks from filename ...
    // assumes that alpha is the last part of filename
    int checks = RandLM::kNoChecks;
    // need at least one extra char
    if (filename.find("checks") < filename.length()+6) {
      checks = atoi(filename.substr(filename.find("checks")+6, filename.find("checks")+7).c_str());
      std::cerr << "set checks = " << checks << std::endl;
    }
    float alpha = 0.4;
    // need at least one extra char for alpha
    if (filename.find("alpha") < filename.length()+6) {
      alpha = atof(filename.substr(filename.find("alpha")+5).c_str());
    }
    assert(checks >= 0 && checks <= 2);
    assert(alpha > 0 && alpha < 1.0);
    assert(cache_size > 0);
    // set parameters and load info
    RandLMFile fin(filename, std::ios::in);
    RandLMInfo* info = new RandLMInfo(&fin);
    assert(info->getMaxOrder() >= order);
    if (info->getMaxOrder() > order) {
      std::cerr << "WARNING: loading an " << info->getMaxOrder() << "-gram RandLM but only"
		<< " used as a " << order << "-gram LM." << std::endl;
    }
    info->setSmoothingParam(alpha);
    info->setCacheSize(cache_size);
    return RandLM::initRandLM(info, &fin, checks);
  }

  RandLM* RandLM::initRandLM(RandLMInfo* info, Vocab* vocab) {
    // instantiate correct type of randlm based on smoothing scheme in info
    assert(info != NULL && vocab != NULL);
    switch (info->getSmoothingScheme()) {
    case RandLM::kStupidBackoffSmoothingCode:
      return new StupidBackoffRandLM(info, vocab);
    case RandLM::kWittenBellSmoothingCode:
      return new WittenBellRandLM(info, vocab);
    case RandLM::kBackoffSmoothingCode:
      return new BackoffRandLM(info, vocab);
    }
    assert(false);
  }
  
  RandLM* RandLM::initRandLM(RandLMInfo* info, RandLMFile* fin, int checks) {
    // instantiate correct type of randlm based on smoothing scheme in info
    assert(info != NULL && fin != NULL);
    switch (info->getSmoothingScheme()) {
    case RandLM::kStupidBackoffSmoothingCode:
      return new StupidBackoffRandLM(info, fin, checks);
    case RandLM::kWittenBellSmoothingCode:
      return new WittenBellRandLM(info, fin, checks);
    case RandLM::kBackoffSmoothingCode:
      return new BackoffRandLM(info, fin, checks);
    }
    assert(false);
  }

  // set up the other member data
  bool RandLM::initMembers() {
    assert(info_ != NULL);
    // determine event types and indices
    main_event_ = info_->getEventType() & (RandLMInfo::kCountEvent | RandLMInfo::kLogProbEvent);
    aux_event_ = info_->getEventType() & (RandLMInfo::kHistoryEvent | RandLMInfo::kBackoffWeightEvent);
    // check exactly one main and at most one aux event
    assert(RandLMInfo::getNumEvents(main_event_) == 1);
    assert(RandLMInfo::getNumEvents(aux_event_) == 1 ||
	   RandLMInfo::getNumEvents(aux_event_) == 0);
    num_events_ = RandLMInfo::getNumEvents(main_event_) + RandLMInfo::getNumEvents(aux_event_);
    max_codes_ = new int[num_events_];
    // other misc data
    order_ = info_->getMaxOrder();
    // ngrams stored in model
    num_ngrams_ = new uint64_t[order_];
    for (int i = 0; i < order_; ++i)
      num_ngrams_[i] = 0;
    // assign 1/2 of cache to hash map. assume other caches approximately same size.
    probCache_ = new RandLMHashCache(info_->getCacheSize() << 19, order_);  // 1 << 19 = 0.5MB in bytes
    return true;
  }
  // i/o
  bool RandLM::save(const std::string& path) {
    RandLMFile fout(path, std::ios::out);
    std::cerr << "Saving RandLM to " << path << std::endl;
    return save(&fout);
  }
  bool RandLM::save(RandLMFile* fout) {
    assert(vocab_ != NULL && info_ != NULL && struct_ != NULL);
    assert(info_->save(fout));  // written first and read prior to instantiating
    assert(vocab_->save(fout));
    assert(struct_->save(fout));
    for (int i = 0; i < order_; ++i)
      assert(fout->write((char*)&num_ngrams_[i], sizeof(num_ngrams_[i])));
    assert(fout->write((char*)&distinct_unigrams_, sizeof(distinct_unigrams_)));
    assert(fout->write((char*)&uniform_log10prob_, sizeof(uniform_log10prob_)));
    return true;
  }
  bool RandLM::load(RandLMFile* fin) {
    assert(info_ != NULL && fin != NULL);  // info_ has already been read from file
    assert(vocab_ == NULL && struct_ == NULL);
    vocab_ = new Vocab(fin);
    assert(vocab_ != NULL);
    struct_ = RandLMStruct::initStructFromFile(info_, fin);
    total_ = 0;
    for (int i = 0; i < order_; ++i){
      assert(fin->read((char*)&num_ngrams_[i], sizeof(num_ngrams_[i])));
      total_ += num_ngrams_[i];
      std::cerr << i+1 << "-grams = " << num_ngrams_[i] << std::endl;
    }
    assert(fin->read((char*)&distinct_unigrams_, sizeof(distinct_unigrams_)));
    assert(fin->read((char*)&uniform_log10prob_, sizeof(uniform_log10prob_)));
    std::cerr << "Distinct unigrams = " << distinct_unigrams_ << std::endl;
    std::cerr << "Uniform log prob for OOV = " << uniform_log10prob_ << std::endl; 
    std::cerr << "Bits per ngram = " << static_cast<float>(struct_->getSize())
      /static_cast<float>(total_) << std::endl;
    return true;
  }  
  const std::string& RandLM::getOOV() {
    return Vocab::kOOVWord;
  }
  const std::string& RandLM::getBOS() {
    return Vocab::kBOS;
  }
  const std::string& RandLM::getEOS() {
    return Vocab::kEOS;
  }
  bool RandLM::build(InputData* data, Stats* stats, float working_mem) {
    assert(data != NULL && stats != NULL && !built_);
    // make sure matches info
    assert(!(info_->isOrderSpecific() && !stats->isOrderSpecific()));
    // setup quantiser(s)
    assert(setupQuantisers(stats));
    // get quantised stats and pass to struct to optimise space
    assert(optimiseStruct(stats, working_mem));
    std::cerr << "Total main events = " << stats->total_main() << std::endl;
    std::cerr << "Total main aux = " << stats->total_aux() << std::endl;
    // store data
    std::cerr << "Storing data...." <<std::endl; 
    built_ = build(data);
    // get total number of distinct unigrams
    distinct_unigrams_ = vocab_->getVocabSize() - 1; // don't include <unk> 
    uniform_log10prob_ = log10(1.0/static_cast<float>(distinct_unigrams_));
    return built_;
  }
  bool RandLM::build(InputData* data) {
    // assume ngrams and batch estimation
    assert(!data->isCorpusData());
    assert(info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
    NgramFile* ngrams = dynamic_cast<NgramFile*>(data);
    return buildFromNgrams(ngrams);
  }
  bool RandLM::buildFromNgrams(NgramFile* ngrams){
    // add ngrams to model
    assert(ngrams != NULL);
    assert(info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
    WordID ngram[RandLM::kMaxNgramOrder];
    int len;
    Value value;
    uint64_t stored = 0;
    // iterate over ngram file once
    assert(ngrams->reset());
    while (ngrams->nextEntry(&ngram[0], &len, &value)) {
      if(!storeNgram(&ngram[0], len, value))  // derived
	for (int i = 0; i < len; ++i)
	  std::cerr << vocab_->getWord(ngram[i]) << ((i < len-1) ? " " : "\n");
      ++stored;
      if (stored % 10000000 == 0)
	std::cerr << "Stored " << stored << " ngrams." << std::endl;
    }
    return true;
  }
  bool RandLM::specifyBatch(EventType event, Stats* stats, Quantiser* quantiser) {
    // specify number of codes that will be inserted of this type
    assert(struct_ != NULL);
    assert(info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
    // get almgamated stats or order specific
    for (int i = 0; i < (info_->isOrderSpecific() ? order_ : 1); ++i) {
      CodeCounts counts;
      // get counts of each code if variable encodings 
      assert(stats->getQuantisedCounts(quantiser, counts, event, 
				       info_->isOrderSpecific() ? i + 1 : 0));
      uint64_t total(0);                                                                                    
      for (CodeCounts::iterator iter = counts.begin(); iter != counts.end(); ++iter)
        total += iter->second;
      // pass counts of codes to structure 
      assert(struct_->setCodeCounts(counts, total, (event == main_event_) ? kMainEventIdx : kAuxEventIdx,
				    info_->isOrderSpecific() ? i + 1 : 0));
    }
    return true;
  }
  // CountRandLM
  bool CountRandLM::initMembers() {
    assert(info_ != NULL && struct_ != NULL);
    // cast struct to subclass if using online estimation
    if (info_->getEstimator() != RandLMStruct::kBatchEstimationCode) {
      online_struct_ = dynamic_cast<OnlineRandLMStruct*>(struct_);
      assert(online_struct_ != NULL);
    } else {
      online_struct_ = NULL;
    }
    countCodeCache_ = new RandLMCache<int>(RandLMStruct::kUnknownCode, RandLMStruct::kNullCode);
    return true;
  }
  bool CountRandLM::load(RandLMFile* fin) {
    // load member data
    assert(info_ != NULL && fin != NULL);
    // quantiser first
    log_quantiser_ = new LogQuantiser(info_, fin, RandLMInfo::kAnyCountEvent);
    assert(setupMaxCodes());
    assert(log_quantiser_ != NULL);
    assert(fin->read((char*)&corpus_size_, sizeof(corpus_size_)));
    std::cerr << "Corpus size = " << corpus_size_ << std::endl;
    std::cerr << "Bits per token = " 
	      << static_cast<float>(struct_->getSize()) / static_cast<float>(corpus_size_) << std::endl;
    return true;
  }
  bool CountRandLM::save(RandLMFile* fout) {
    // save base first (since initialised in that order)
    assert(fout != NULL);
    assert(RandLM::save(fout));
    assert(log_quantiser_ != NULL);
    assert(log_quantiser_->save(fout));
    assert(fout->write((char*)&corpus_size_, sizeof(corpus_size_)));
    return true;
  }
  bool CountRandLM::build(InputData* data) {
    // determine what type of data
    if (data->isCorpusData()) {
      assert(info_->getEstimator() != RandLMStruct::kBatchEstimationCode);
      Corpus* corpus = dynamic_cast<Corpus*>(data);
      assert(corpus != NULL);
      assert(buildFromCorpus(corpus));
    } else {
      assert(data->isCountData());
      assert(info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
      NgramFile* ngrams = dynamic_cast<NgramFile*>(data);
      assert(ngrams != NULL);
      assert(buildFromNgrams(ngrams));
    }
    return true;
  }
  bool CountRandLM::buildFromCorpus(Corpus* corpus) {
    // insert data from corpus
    assert(corpus != NULL);
    assert(info_->getEstimator() != RandLMStruct::kBatchEstimationCode);
    WordID sentence[Corpus::kMaxSentenceWords];
    int len;
    // let the struct know the counting scheme
    assert(online_struct_ != NULL && online_struct_->assignCountMapping(log_quantiser_));
    // iterate over corpus once
    assert(corpus->reset());
    while (corpus->nextSentence(&sentence[0], &len)) {
      assert(storeSentence(&sentence[0], len));
      if (corpus->getLineNumber() % 10000 == 0)
	online_struct_->printOnlineStats();
    }
    return true;
  }
  bool CountRandLM::storeNgram(const WordID* ngram, int len, Value value) {
    // store the count information associated with this ngram
    float count(0), history(0); // ignore history
    assert(CountFile::convertFromValue(value, &count, &history));
    // update corpus stats
    num_ngrams_[len-1] = count > 0 ? num_ngrams_[len-1] + 1 : num_ngrams_[len-1];
    // don't count <s>
    corpus_size_ = (len == 1 && ngram[0] != Vocab::kBOSWordID) 
      ? corpus_size_ + static_cast<uint64_t>(count) : corpus_size_;
    // print out quantised counts
    if (count > 0)
      return struct_->insert(ngram, len, kMainEventIdx, log_quantiser_->getCode(count));
    return true;
  }
  bool CountRandLM::storeSentence(const WordID* sentence, int len) {
    // update model to store counts of ngrams in this sentence
    corpus_size_ += (len - 1);  // don't count <s>
    for (int n = 1; n <= order_; ++n)
      for (int i = 0; i < len - n + 1; ++i) 
	if (online_struct_->count(sentence[i], i, i+n-1))
	  ++num_ngrams_[n-1]; // returning true indicates new ngram
    return true;
  }
  bool CountRandLM::setupMaxCodes() {
    assert(log_quantiser_ != NULL);
    max_codes_[kMainEventIdx] = log_quantiser_->getMaxCode();
    if (num_events_ == 2) // same quantiser
      max_codes_[kAuxEventIdx] = log_quantiser_->getMaxCode();
    return true;
  }
  bool CountRandLM::setupQuantisers(Stats* stats) {
    // set up log quantiser for counts
    assert(info_ != NULL && stats != NULL);
    log_quantiser_ = new LogQuantiser(info_, stats, RandLMInfo::kAnyCountEvent); 
    return setupMaxCodes();
  }
  bool CountRandLM::optimiseStruct(Stats* stats, float working_mem) {
    // determine estimation method
    assert(log_quantiser_ != NULL && struct_ != NULL && stats != NULL);
    // check have correct statitistics estimated
    if (info_->getEstimator() == RandLMStruct::kBatchEstimationCode) {
      assert(stats->hasNgramStats());
      // set expected number of count events to store
      assert(specifyBatch(RandLMInfo::kCountEvent, stats, log_quantiser_));
      // set expected histories if any
      if (info_->getEventType() & RandLMInfo::kHistoryEvent)
	assert(specifyBatch(RandLMInfo::kHistoryEvent, stats, log_quantiser_));
      // optimise structure
    } else {
      assert(online_struct_ != NULL);
      if (stats->hasTokenStats()) // not really required
	assert(online_struct_->setExpectedTokens(stats->getTokenCount()));
    }
    return struct_->optimise(working_mem);
  }
  float CountRandLM::getCount(const WordID* ngram, int len) {
    // retrieve count of this ngram 
    int code = max_codes_[kMainEventIdx];
    bool found = true;
    int start = len - 1; // gcc insists... on some platforms
    switch (checks_) {
    case kNoChecks:
      // query full ngram immediately (can't be in cache)
      found = struct_->query(ngram, len, kMainEventIdx, &code);
      break;
    case kStandardChecks:
      // apply checks for rightmost unigram first then extending to left
      //int start = len - 1;
      while (start >= 0 && found) {
	found = ngram[start] != Vocab::kOOVWordID  
	  && struct_->query(ngram[start], start, len - 1, kMainEventIdx, &code, code);
	--start;
      }
      break;
    case kAllChecks:
      // check for all subngrams
      for (int end = len - 1; found && end >= 0; --end) { // end index
	int thiscode = max_codes_[kMainEventIdx]; // bound ngrams with same end pos separately
	for (int start = end; found && start >= 0; --start) // build up to right
	  found = ngram[start] != Vocab::kOOVWordID &&
	    struct_->query(ngram[start], start, end, kMainEventIdx, &thiscode, thiscode);
	// apply global bound
	code = thiscode < code ? thiscode : code;
      }
      break;
    }
    return found ? log_quantiser_->getValue(code) : 0;
  }


  // StupidBackoffRandLM implements simple backoff algorithm
  bool StupidBackoffRandLM::initScheme() {
    // init smoothing scheme specific data 
    assert(info_ != NULL);
    backoff_constant_ = info_->getSmoothingParam();
    std::cerr << "Stupid backoff constant = " << backoff_constant_ << std::endl;
    assert(backoff_constant_ > 0 && backoff_constant_ < 1); // not log prob
    stupid_backoff_log10_ = new float[order_ + 1];
    for (int i = 0; i < order_ + 1; ++i) {
      stupid_backoff_log10_[i] = i * log10(backoff_constant_);
      std::cerr << "Stupid backoff order[" << i <<"] = " << stupid_backoff_log10_[i] << std::endl;
    }
    std::cerr << "Stupid backoff zero order log prob = " << uniform_log10prob_ << std::endl;
    corpus_size_log10_ = log10(corpus_size_);
    return true;
  }
  float StupidBackoffRandLM::getProb(const WordID* ngram, int len, int* found, const void** state) {
    // retrieve sbo prob. three algorithms using increasinly more checks.
    // Assumes that model structure ensures: ABC -> BC -> C etc. 
    float log_prob(0);
    const void* context_state(NULL);
    if (probCache_->check(ngram, len, &log_prob, &context_state)) {
      if (state)
	*state = context_state;
      return log_prob;
    } else {  // check if failure due to cache filling up
      if (probCache_->full()) {
	countCodeCache_->clearCache(); 
	probCache_->clearCache();
	probCache_->check(ngram, len, &log_prob, &context_state); // reload ngram if cleared
	// fails if cache is too small to store a single ngram
	assert(!probCache_->full());  
      }
    }
    int* denom_codes[RandLM::kMaxNgramOrder];
    int* num_codes[RandLM::kMaxNgramOrder + 1];
    int denom_found(0);
    // constrain cache queries using model assumptions
    int denom_len = countCodeCache_->getCache(ngram, len - 1, &denom_codes[0], &denom_found);
    int num_len = countCodeCache_->getCache(&ngram[len - denom_len - 1], denom_len + 1, 
					    &num_codes[0], found); 
    switch (checks_) {
    case kNoChecks: { // just makes sure no division by zero or OOV terms
      // keed reducing ngram size until both denominator and numerator are found
      // allowed to leave kUnknownCode in cache because we check for this.

      *found = num_len; // guaranteed to be <= denom_len + 1
      // still check for OOV
      for (int i = len - *found; i < len; ++i)
	if (ngram[i] == Vocab::kOOVWordID) {
	    *found = len - i - 1;
	}
      // check for relative estimator
      while(*found > 1) {
	if (*denom_codes[*found - 1] == RandLMStruct::kUnknownCode &&  
	    !struct_->query(&ngram[len-*found], *found-1, kMainEventIdx, denom_codes[*found-1])) {
	  *num_codes[*found] = RandLMStruct::kUnknownCode;
	} else {
	  if (*num_codes[*found] != RandLMStruct::kUnknownCode ||
	      struct_->query(&ngram[len-*found], *found, kMainEventIdx, 
			     num_codes[*found], *denom_codes[*found-1]))
	    break;
	}	
	--(*found);
      }
      // didn't find bigram numerator or unigram denominator 
      if (*found == 1)
	*found = *num_codes[1] != RandLMStruct::kUnknownCode 
	  || struct_->query(&ngram[len - 1], 1, kMainEventIdx, num_codes[1]);
      break;
    }
    case kAllChecks: {
      // checks for all possible subngrams 
      int startpos = len - denom_len - 1;  
      int endpos = startpos;
      int* other_codes[RandLM::kMaxNgramOrder][RandLM::kMaxNgramOrder];
      int other_found(0);
      // query null suffix to get 'upper bound'
      int other_len = countCodeCache_->getCache(NULL, 0, &other_codes[0][0], &other_found);
      // check subngrams up to denominator minus last word
      while (endpos < len - 2) {  
	other_len = countCodeCache_->getCache(&ngram[startpos], endpos - startpos + 1,
					      &other_codes[endpos + 1][0], &other_found);      
	// check suffixs of this subngram
	if (other_len) {
	  if (other_found) { // full query
	    while (other_found < other_len) {
	      // check OOV for new endpos
	      if (ngram[endpos - other_found] == Vocab::kOOVWordID) {
		other_len = other_found;
		*other_codes[endpos + 1][other_found + 1] = RandLMStruct::kNullCode;
		break;
	      } else {
		if (!struct_->query(&ngram[endpos - other_found],
				    other_found + 1, kMainEventIdx,other_codes[endpos + 1][other_found + 1],
				    std::min(*other_codes[endpos + 1][other_found],
					     *other_codes[endpos][other_found])))
		  break;
	      }
	      other_found++;
	    }
	  } else {
	    // incremental query
	    while (other_found < other_len) {
	      if (ngram[endpos - other_found] == Vocab::kOOVWordID) {
		other_len = other_found;
		*other_codes[endpos + 1][other_found + 1] = RandLMStruct::kNullCode;
		break;
	      } else {
		if (!struct_->query(ngram[endpos - other_found], endpos - other_found,
				    endpos, kMainEventIdx, other_codes[endpos + 1][other_found + 1], 
				    std::min(*other_codes[endpos + 1][other_found],
					     *other_codes[endpos][other_found])))
		  break;
	      }
	      other_found++;
	    }
	  }
	}
	// if not all found then update denom_len, startpos and num_len appropriately
	if (other_found < endpos - startpos + 1) { 
	  startpos = endpos + 1 - other_found;  // shift start to left
	  // truncate denominator
	  *denom_codes[len - startpos] = RandLMStruct::kNullCode;
	  denom_len = len - startpos - 1;
	  // truncate numerator
	  if (num_len > denom_len + 1) {
	    *num_codes[denom_len + 2] = RandLMStruct::kNullCode;
	    num_len = denom_len + 1;
	  }
	}
	endpos++;
      }
      // remainder is as for kStandardChecks so drop through
    }
    case kStandardChecks: {
      // we always assume that subngrams have already been queried.
      // not allowed to leave kUnknownCode in cache since we never check for this.
      // so must query until not found or exhausted for each end position.
      
      // query for denominator first since this can be used to bound numerator.
      if (denom_found) {  // extending existing denominator so can't use incremental query
	while (denom_found < denom_len) {
	  // check OOV for each new word
	  if (ngram[len - denom_found - 2] == Vocab::kOOVWordID) {
	    denom_len = denom_found;
	    *denom_codes[denom_found + 1] = RandLMStruct::kNullCode;
	    break;
	  } else {
	    if (!struct_->query(&ngram[len - denom_found - 2], denom_found + 1,
				kMainEventIdx,
				denom_codes[denom_found + 1], *denom_codes[denom_found]))
	      break;
	  }
	  denom_found++;
	}
      } else {  // incremental queries since completely new
	while (denom_found < denom_len) {
	  // check OOV for each new word
	  if (ngram[len - denom_found - 2] == Vocab::kOOVWordID) {
	    denom_len = denom_found;
	    *denom_codes[denom_found + 1] = RandLMStruct::kNullCode;
	    break;
	  } else {
	    if (!struct_->query(ngram[len - denom_found - 2], len - denom_found - 2,
				len - 2, kMainEventIdx, denom_codes[denom_found + 1], 
				*denom_codes[denom_found])) 
	      break;
	  }
	  denom_found++;
	}
      }
      // truncate numerator possibilities
      if (num_len > denom_found + 1) {
	*num_codes[denom_found + 2] =  RandLMStruct::kNullCode;
	num_len = denom_found + 1;
      }
      // query for numerator using denominator as an upper bound
      if (*found) { // extending existing numerator so can't use incremental query functions
	while (*found < num_len &&
	       struct_->query(&ngram[len - *found - 1], *found + 1, kMainEventIdx,
			      num_codes[*found + 1], 
			      std::min(*num_codes[*found], *denom_codes[*found])))
	  (*found)++;
      } else { // incremental queries since completely new
	// check OOV for unigram
	if (ngram[len - 1] == Vocab::kOOVWordID) {
	  num_len = 0;
	  *num_codes[1] = RandLMStruct::kNullCode;
	} 
	while (*found < num_len &&
	       struct_->query(ngram[len - *found - 1], len - *found - 1, len - 1, 
			      kMainEventIdx, num_codes[*found + 1], 
			      std::min(*num_codes[*found], *denom_codes[*found])))
	  (*found)++;
      }
      break;
    }
    }  // closes switch (checks_)
    // return estimate applying correct backoff score (precomputed)
    switch (*found) {
    case 0: // no observation: assign prob of 'new word' in training data
      log_prob = stupid_backoff_log10_[len - *found] + uniform_log10prob_;
      break;
    case 1: // unigram over whole corpus
      log_prob = log_quantiser_->getLog10Value(*num_codes[*found]) - corpus_size_log10_ 
	+ stupid_backoff_log10_[len - *found];  // precomputed
      break;
    default: // otherwise use both statistics and (possibly zero) backoff weight
      log_prob = log_quantiser_->getLog10Value(*num_codes[*found ]) 
	- log_quantiser_->getLog10Value(*denom_codes[*found - 1]) 
	+ stupid_backoff_log10_[len - *found];
    }
    // store full log prob with complete ngram (even if backed off)
    context_state = (const void*)num_codes[*found == len ? *found - 1 : *found];;
    probCache_->store(len, log_prob, context_state); 
    if (state)
      *state = context_state;
    return log_prob;
  }
  // WittenBellRandLM implements context dependent smoothing
  bool WittenBellRandLM::initMembers() {
    // init smoothing scheme specific data 
    assert(info_ != NULL);
    num_histories_ = new uint64_t[order_];
    for (int i = 0; i < order_; ++i)
      num_histories_[i] = 0;
    historyCodeCache_ = new RandLMCache<int>(RandLMStruct::kUnknownCode, RandLMStruct::kNullCode);
    return true;
  }
  bool WittenBellRandLM::initScheme() {
    std::cerr << "initialising witten bell smoothing" << std::endl;
    // compute statistics required for Witten Bell smoothing (these are not written to file)
    assert(max_codes_ != NULL && log_quantiser_ != NULL);  // these must be setup first
    // set up precomputed statistics for Witten Bell
    zero_order_prob_ =  1 / static_cast<double>(distinct_unigrams_);
    zero_backoff_ = 1 - (static_cast<float>(distinct_unigrams_) /
			 static_cast<float>(distinct_unigrams_ + corpus_size_));
    initial_term_ = (1 - zero_backoff_) * zero_order_prob_; // initialise wb prob with this
    std::cerr << "params:" << zero_order_prob_ << " " << zero_backoff_ << " " << initial_term_ << std::endl;
    assert(initial_term_ > 0);
    // unigram vector
    unigram_probs_ = new float[max_codes_[kMainEventIdx] + 1];
    // matrix for higher orders
    mle_probs_ = new float*[max_codes_[kMainEventIdx] + 1];
    for (int i = 0; i <= max_codes_[kMainEventIdx]; ++i) {
      unigram_probs_[i] = std::min(zero_backoff_, zero_backoff_ * 
				   (log_quantiser_->getValue(i)/static_cast<float>(corpus_size_))) 
	+ initial_term_;
      assert(unigram_probs_[i] > 0 && unigram_probs_[i] < 1);
      mle_probs_[i] = new float[max_codes_[kMainEventIdx] + 1];
      for (int j = 0; j <= max_codes_[kMainEventIdx]; ++j) {
	// i = numerator j = denominator
	mle_probs_[i][j] = i <= j ? (log_quantiser_->getValue(i) / log_quantiser_->getValue(j)) : 1;
	assert(mle_probs_[i][j] >= 0 && mle_probs_[i][j] <= 1);
      }
    }
    backoffs_ = new float*[max_codes_[kAuxEventIdx] + 1];
    for (int i = 0; i <= max_codes_[kAuxEventIdx]; ++i) {
      backoffs_[i] = new float[max_codes_[kMainEventIdx]];
      for (int j = 0; j <= max_codes_[kMainEventIdx]; ++j) {
	// i = retrieved code + 1, j = denom code
	// backoff[i][j] = 1.0 - (value(i - 1) + 1)/(value(i - 1) + 1 + value(j))
	if (i == 0)
	  backoffs_[i][j] = 1.0 - 1.0/(1.0 + log_quantiser_->getValue(j));
	else
	  backoffs_[i][j] = 1.0 - (log_quantiser_->getValue(i - 1) + 1.0)
	    / (log_quantiser_->getValue(i - 1) + 1.0 + log_quantiser_->getValue(j));
	backoffs_[i][j] = std::max(0.5f, backoffs_[i][j]);
	assert(backoffs_[i][j] >= 0.5f && backoffs_[i][j] <= 1);
      }
    }
    return true;
  }
  bool WittenBellRandLM::load(RandLMFile* fin) {
    assert(info_ != NULL && fin != NULL);
    for (int i = 0; i < order_; ++i)
      assert(fin->read((char*)&num_histories_[i], sizeof(num_histories_[i])));
    return true;
  }
  bool WittenBellRandLM::save(RandLMFile* fout) {
    // call parent first 
    assert(info_ != NULL && fout != NULL);
    assert(CountRandLM::save(fout));
    for (int i = 0; i < order_; ++i)
      assert(fout->write((char*)&num_histories_[i], sizeof(num_histories_[i])));
    return true;
  }  
  float WittenBellRandLM::getProb(const WordID* ngram, int len, int* found, const void** state) {
    // get conditional log prob via witten bell smoothing
    float log_prob(0);
    const void* context_state(NULL);
    if (probCache_->check(ngram, len, &log_prob, &context_state)) {
      if (state)
	*state = context_state;
      return log_prob;
    } else {  // check if failure due to cache filling up
      if (probCache_->full()) {
	countCodeCache_->clearCache(); historyCodeCache_->clearCache();
	probCache_->clearCache();
	probCache_->check(ngram, len, &log_prob, &context_state); // reload ngram if cleared
	assert(!probCache_->full());  // fails if cache is too small to store a single ngram
	
      }
    }
    int* denom_codes[RandLM::kMaxNgramOrder];
    int* num_codes[RandLM::kMaxNgramOrder + 1];
    int* history_codes[RandLM::kMaxNgramOrder];
    int denom_found(0), history_found(0); // longest definitely cached
    // constrain cache queries using model assumptions
    int denom_len = countCodeCache_->getCache(ngram, len - 1, &denom_codes[0], &denom_found);
    int history_len = historyCodeCache_->getCache(&ngram[len - denom_len - 1], denom_len,
						  &history_codes[0], &history_found); 
    int num_len = countCodeCache_->getCache(&ngram[len - denom_len - 1], denom_len + 1,
					    &num_codes[0], found); 
    for (int i = 1; i <= *found; ++i)
      assert(*num_codes[i] != RandLMStruct::kUnknownCode);
    int history_code(0); // required because inferred from denom_code sometimes
    // Always performs checks: starts with unigram and work up applying bounds
    if (!*found && num_len) {
      if (ngram[len - 1] == Vocab::kOOVWordID ||
	  !struct_->query(&ngram[len - 1], 1, kMainEventIdx, num_codes[1])) {
	num_len = 0;
	*num_codes[1] = RandLMStruct::kNullCode;
      } else {
	*found = 1;
      }
    }
    // initialize with precomputed unigram score  =  backoff(0)*mle(1) + (1 - backoff_(0))*mle(0)
    // or initial prob  = (1 - backoff(0)) * mle(0)
    float wb_prob = *found ? unigram_probs_[*num_codes[1]] : initial_term_;
    // if found then query denom/history/numerator triples in turn moving index left
    int pos = len - 2;  // next word to include
    // TODO: implement 'incremental' query algorithm for when denom_found = 0
    while (pos >= len - denom_len - 1) {
      // query new position for denominator (i.e. ngram from newpos to len-2)
      if(denom_found < len - pos - 1) {
	if (ngram[pos] == Vocab::kOOVWordID || 
	    !struct_->query(&ngram[pos], len - pos - 1, kMainEventIdx, 
			    denom_codes[len - pos - 1], *denom_codes[len - pos - 2])) {
	  *denom_codes[len - pos - 1] = RandLMStruct::kNullCode;
	  if (num_len >= len - pos)
	    *num_codes[len - pos] = RandLMStruct::kNullCode;
	  if (history_len >= len - pos - 1)
	    *history_codes[len - pos - 1] = RandLMStruct::kNullCode;
	  break;
	} else {
	  ++denom_found;
	}
      }
      // query for history if denom count >= 2
      if (history_len >= len - pos - 1 && history_found < len - pos - 1) {
	if (log_quantiser_->getValue(*denom_codes[len - pos - 1]) < 2 || 
	    !struct_->query(&ngram[pos], len - pos - 1, kAuxEventIdx, history_codes[len - pos - 1], 
			    std::min(*history_codes[len - pos - 2], *denom_codes[len - pos - 1]))) {
	  *history_codes[len - pos - 1] = RandLMStruct::kNullCode;
	  history_len = len - pos;
	}
      }
      // query new position for numerator 
      if(num_len >= len - pos && *found < len - pos) {
	if (struct_->query(&ngram[pos], len - pos, kMainEventIdx, num_codes[len - pos],
			   std::min(*num_codes[len - pos - 1], *denom_codes[len - pos - 1]))) {
	  ++(*found);
	} else {
	  num_len = len - pos - 1;
	}
      }
      // wb_prob[*found] = backoffs_[*found] * mle[*found] + (1-backoffs_[*found]) * wbprob[*found - 1]		 
      history_code = (len - pos - 1 > history_len) ? -1 : *history_codes[len - pos - 1];
      // add in mle if one
      if (num_len >= len - pos && *num_codes[len - pos] >= 0) {
	//std::cerr << history_code << " " << len << " " << pos << " " << *found << std::endl;
	//std::cerr << *num_codes[len - pos] << std::endl;
	//std::cerr << *denom_codes[len - pos - 1] << std::endl;
	wb_prob = backoffs_[history_code + 1][*denom_codes[len - pos - 1]] 
	  * mle_probs_[*num_codes[len - pos]][*denom_codes[len - pos - 1]] 
	  + (1.0 - backoffs_[history_code + 1][*denom_codes[len - pos - 1]]) * wb_prob;
	assert(wb_prob > 0);
      } else { // just backoff weight
	wb_prob = (1.0 - backoffs_[history_code + 1][*denom_codes[len - pos - 1]]) * wb_prob;
	assert(wb_prob > 0);
      }
      --pos;
    }
    // store full log prob with complete ngram (even if backed off)
    log_prob = log10(wb_prob);
    // pass pointer to context
    context_state = (const void*)num_codes[*found == len ? *found - 1 : *found];
       probCache_->store(len, log_prob, context_state);
    if (state)
     *state = context_state;
    return log_prob;
  }
  float WittenBellRandLM::getHistoryCount(const WordID* history, int len, int* found) {
    // retrieve count of this 'history'
    return false; // broken due to subtracted code getCount(history, len, found, RandLMInfo::kHistoryEvent);
  }
  bool WittenBellRandLM::storeNgram(const WordID* ngram, int len, Value value) {
    assert(len > 0 && len <= order_);
    // store the count information associated with this ngram and history
    float count(0), history(0); 
    assert(CountFile::convertFromValue(value, &count, &history));
    // update corpus stats
    num_ngrams_[len-1] = count > 0 ? num_ngrams_[len-1] + 1 : num_ngrams_[len-1];
    num_histories_[len-1] = history > 0 ? num_histories_[len-1] + 1 : num_histories_[len-1];
    corpus_size_ = (len == 1 && ngram[0] != Vocab::kBOSWordID)
      ? corpus_size_ + static_cast<uint64_t>(count) : corpus_size_;
    // only insert non-zero events
    bool inserted = true;
    if (count > 0)
      inserted = struct_->insert(ngram, len, kMainEventIdx, log_quantiser_->getCode(count));
    if (inserted && len > 1 && history > 1)  // only store code for history - 1
      return struct_->insert(ngram, len - 1, kAuxEventIdx, log_quantiser_->getCode(history - 1));
    return inserted;
  }

  // BackoffRandLM implements backoff smoothing
  bool BackoffRandLM::setupQuantisers(Stats* stats) {
    // set up uniform quantisers for logprobs and boweights
    assert(info_ != NULL && stats != NULL && stats->hasNgramStats());
    log_prob_quantiser_ = new UniformQuantiser(info_, stats, RandLMInfo::kLogProbEvent);
    bo_quantiser_ = new UniformQuantiser(info_, stats, RandLMInfo::kBackoffWeightEvent);
    return log_prob_quantiser_ != NULL && bo_quantiser_ != NULL;
  }
  bool BackoffRandLM::initMembers() {
    assert(info_ != NULL);
    num_boweights_ = new uint64_t[order_];
    for (int i = 0; i < order_; ++i)
      num_boweights_[i] = 0;
    logProbCache_ = new RandLMCache<int>(RandLMStruct::kUnknownCode, RandLMStruct::kNullCode);
    boWeightCache_ = new RandLMCache<int>(RandLMStruct::kUnknownCode, RandLMStruct::kNullCode);
    return true;
  }
  bool BackoffRandLM::setupMaxCodes() {
    assert(log_prob_quantiser_ != NULL && bo_quantiser_ != NULL);
    max_codes_[kMainEventIdx] = log_prob_quantiser_->getMaxCode();
    max_codes_[kAuxEventIdx] = bo_quantiser_->getMaxCode();
    std::cerr <<"Set max codes = " << max_codes_[kMainEventIdx] << " " 
	      << max_codes_[kAuxEventIdx] << std::endl; 
    return true;
  }
  bool BackoffRandLM::load(RandLMFile* fin) {
    assert(info_ != NULL && fin != NULL);
    // quantisers first
    log_prob_quantiser_ = new UniformQuantiser(info_, fin, RandLMInfo::kLogProbEvent);
    bo_quantiser_ = new UniformQuantiser(info_, fin, RandLMInfo::kBackoffWeightEvent);
    assert(setupMaxCodes());
    for (int i = 0; i < order_; ++i)
      assert(fin->read((char*)&num_boweights_[i], sizeof(num_boweights_[i])));
    assert(fin->read((char*)&unk_log10prob_, sizeof(unk_log10prob_)));
    return true;
  }
  bool BackoffRandLM::save(RandLMFile* fout) {
    assert(info_ != NULL && fout != NULL);
    // save base first
    assert(RandLM::save(fout));
    // quantisers first
    assert(log_prob_quantiser_ != NULL);
    assert(log_prob_quantiser_->save(fout));
    assert(bo_quantiser_ != NULL);
    assert(bo_quantiser_->save(fout));
    for (int i = 0; i < order_; ++i)
      assert(fout->write((char*)&num_boweights_[i], sizeof(num_boweights_[i])));
    assert(fout->write((char*)&unk_log10prob_, sizeof(unk_log10prob_)));
    return true;
  }
  bool BackoffRandLM::optimiseStruct(Stats* stats, float working_mem) {
    // only implemented for batch estimation
    assert(struct_ != NULL && stats != NULL && stats->hasNgramStats());
    assert(info_->getEstimator() == RandLMStruct::kBatchEstimationCode);
    assert(log_prob_quantiser_ != NULL && bo_quantiser_ != NULL);
    // specify number of log probs
    assert(specifyBatch(RandLMInfo::kLogProbEvent, stats, log_prob_quantiser_));
    // and backoff weights
    assert(specifyBatch(RandLMInfo::kBackoffWeightEvent, stats, bo_quantiser_));
    return struct_->optimise(working_mem);
  }

  float BackoffRandLM::getProb(const WordID* ngram, int len, int* found, const void** state) {
    // return log prob directly via backoff. cache reduces errors as does setting 'checks' flag
    // the algorithm(s) assume the following implications are valid for the model and an ngram ABC:
    // (i) ABC -> BC -> C for either log probs or bo weights (so longer ngram present only if shorter is)
    // (ii) bo(X) -> lp(X) (so bo present if log prob is.)
    float log_prob(0);
    const void* context_state(NULL);
    if (probCache_->check(ngram, len, &log_prob, &context_state)) {
      if (state)
	*state = context_state;
      return log_prob;
    } else {  // check if failure due to cache filling up
      if (probCache_->full()) {
	logProbCache_->clearCache();
	boWeightCache_->clearCache(); 
	probCache_->clearCache();
	probCache_->check(ngram, len, &log_prob, &context_state); // reload ngram
	assert(!probCache_->full());  // fails if cache is too small to store a single ngram
      }
    }
    // check cache for log prob, bo weights and bo context codes.
    // x_len params give upper bound on length of corresponding events in model.
    // x_found give lengths of events already found and cached.
    int bo_found(0), context_found(0);
    int* log_prob_codes[RandLM::kMaxNgramOrder + 1];
    int* bo_codes[RandLM::kMaxNgramOrder];
    int* context_codes[RandLM::kMaxNgramOrder];
    // constrain cache queries via model assumptions
    int bo_len = boWeightCache_->getCache(ngram, len - 1, &bo_codes[0], &bo_found);
    int lp_len = logProbCache_->getCache(&ngram[len - bo_len - 1], bo_len + 1, &log_prob_codes[0], found); 
    int max_con = std::min(len - 1, lp_len);
    int context_len = boWeightCache_->getCache(&ngram[len-max_con], max_con, &context_codes[0], &context_found);
    log_prob = 0;
    // only distinguish between no or some checks (i.e. checks = 1 and 2 are same).
    if (checks_) {
      // try to extend *found to upper bound lp_len.
      while (*found < lp_len) {
	if (ngram[len - 1 - *found] == Vocab::kOOVWordID) {	  
	  *log_prob_codes[*found + 1] = RandLMStruct::kNullCode; 
	  if (*found < context_len)
	    *context_codes[*found + 1] = RandLMStruct::kNullCode;
	  if (*found && *found < bo_len) {
	    *bo_codes[*found] = RandLMStruct::kNullCode;
	    bo_len = *found - 1;
	  }
	  break;
	}
	// insist that bo weight is present unless unigram
	if (*found && *found > bo_found) {
	  if (*found > bo_len ||
	      !struct_->query(&ngram[len - 1 - *found], *found, kAuxEventIdx, bo_codes[*found])) {
	    *log_prob_codes[*found + 1] = RandLMStruct::kNullCode;  
	    if (*found < context_len)
	      *context_codes[*found + 1] = RandLMStruct::kNullCode;
	    bo_len = *found - 1;
	    break;
	  } else {
	    ++bo_found;
	  }	    
	}
	// check for actual ngram
	if (!struct_->query(&ngram[len - 1 - *found], *found + 1, kMainEventIdx, log_prob_codes[*found + 1])) {
	  if (*found < context_len)
	    *context_codes[*found + 1] = RandLMStruct::kNullCode;
	  break;
	} 
	// check for context here if more potentially in model
	if (context_found < context_len) {
	  if (struct_->query(&ngram[len - 1 - context_found], context_found + 1, 
			     kAuxEventIdx, context_codes[context_found + 1])) {
	    ++context_found;
	  } else {
	    context_len = context_found;
	    *context_codes[context_found + 1] = RandLMStruct::kNullCode;
	  }
	}
	++(*found);
      }
      // get bo costs if any for bo contexts of length *found upwards 
      for (int i = *found ? *found : 1; i <= bo_len; ++i) {
	if (ngram[len - 1 - i] == Vocab::kOOVWordID || 
	    (i > bo_found && !struct_->query(&ngram[len - 1 - i], i, kAuxEventIdx, bo_codes[i])))
	  break;
	log_prob += bo_quantiser_->getValue(*bo_codes[i]);
      }
    } else { // (no checks) standard backoff 
      // find longest ngram with log_prob in model 
      while (lp_len > 0 && *log_prob_codes[lp_len] == RandLMStruct::kUnknownCode &&
	     !struct_->query(&ngram[len - lp_len], lp_len, kMainEventIdx, log_prob_codes[lp_len]))
	--lp_len;
      // add back off costs
      while (bo_len >= lp_len && bo_len > 0) {
	if (*bo_codes[bo_len] != RandLMStruct::kUnknownCode ||
	    struct_->query(&ngram[len - 1 - bo_len], bo_len, kAuxEventIdx, bo_codes[bo_len]))
	  log_prob += bo_quantiser_->getValue(*bo_codes[bo_len]);
	--bo_len;
      }
      *found = lp_len;
      // get context
      while (context_len > context_found) {
	if (struct_->query(&ngram[len - context_len], context_len, 
			   kAuxEventIdx, context_codes[context_len]))
	  break;
	--context_len;
      }
      context_found = context_len;
    }
    // add log prob of retrieve ngram (or uniform if none) to backoff retrieved
    log_prob = *found > 0 ? log_prob + log_prob_quantiser_->getValue(*log_prob_codes[*found]) :
      log_prob + unk_log10prob_; 
    // store full log prob with complete ngram (even if backed off)
    context_state = (const void*)context_codes[context_found];
    probCache_->store(len, log_prob, context_state); 
    if (state)
      *state = context_state;
    return log_prob;
  }

  bool BackoffRandLM::storeNgram(const WordID* ngram, int len, Value value) {
    assert(len > 0 && len <= order_);
    // store the logprob and backoff weight information 
    float logprob(0), boweight(0); // ignore history
    assert(BackoffModelFile::convertFromValue(value, &logprob, &boweight));
    // if unigram <unk> get logprob for unknown word
    if (len == 1 && ngram[0] == Vocab::kOOVWordID) {
      unk_log10prob_ = logprob;
      std::cerr << "set <unk> = " << unk_log10prob_ << std::endl;
      return true;
    }
    // update corpus stats
    ++num_ngrams_[len-1]; // all entries have a valid log-prob  
    num_boweights_[len-1] = BackoffModelFile::ValidWeight(boweight) 
      ? num_boweights_[len-1] + 1 : num_boweights_[len-1];
    // insert logprob
    bool inserted = struct_->insert(ngram, len, kMainEventIdx, log_prob_quantiser_->getCode(logprob));
    // insert non-null bo weights
    if (inserted && BackoffModelFile::ValidWeight(boweight))
      return struct_->insert(ngram, len, kAuxEventIdx, bo_quantiser_->getCode(boweight));
    return inserted;
  }
}
