// Copyright 2008 David Talbot, Abby Levenberg
//
// This file is part of RandLM
//
// RandLM is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// RandLM is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with RandLM.  If not, see <http://www.gnu.org/licenses/>.
#ifndef INC_RANDLM_UTILS_H
#define INC_RANDLM_UTILS_H

#include <stdint.h>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <climits>
#include <string.h>

namespace randlm {

  class RandLMUtils {
  public:
    // test if prime (slow)
    static bool IsPrime(uint64_t num) {
      for (uint64_t i = 3; i*i < num; i += 2)
	if (num % i == 0)
	  return false;
      return true;
    }
    // find next prime larger than num (or 0)
    static uint64_t NextPrime(uint64_t num) {
      uint64_t cand = num | 1;  // make sure odd
      while (cand >= num) {
	if (IsPrime(cand))  // test
	  return cand;
	cand += 2;
      }
      return 0;  // failed to find prime ...
    }
    // TODO: interface with decent PRG
    static uint32_t Rand(uint32_t) {
      return rand();
    }
    static uint64_t Rand(uint64_t) {
      // get two 32bit rands and concatenate
      uint64_t longrand = rand();
      longrand <<= 32;
      longrand |= rand();
      return longrand;
    }
    static double Rand(double) {
      return static_cast<double>(rand());
    }
    static double UniformAtRandom() {
      // broken ....
      return static_cast<double>(rand())/static_cast<double>(INT_MAX);
    }
    static std::string IntToStr(int integer) {
      std::ostringstream stream;
      stream << integer;
      return stream.str();
    }

    static std::string Uint64ToString(uint64_t longInt) {
      std::ostringstream stream;
      stream << longInt;
      return stream.str();
    }
    static std::string FloatToString(float f) {
      std::ostringstream stream;
      stream << f;
      return stream.str();
    }

    static int StringToInt(const std::string & str) {
      std::istringstream stream(str.c_str());
      int integer;
      stream >> integer;
      return integer;
    }

    static uint64_t StringToUint64(const std::string & str) {
      std::istringstream stream(str.c_str());
      uint64_t integer;
      stream >> integer;
      return integer;
    }

    static uint32_t StringToUint32(const std::string & str) {
      std::istringstream stream(str.c_str());
      uint32_t integer;
      stream >> integer;
      return integer;
    }
    static float StringToFloat(const std::string & str) {
      std::istringstream stream(str.c_str());
      float f;
      stream >> f;
      return f;
    }
    static bool StringToBool(const std::string & str) {
      std::istringstream stream(str.c_str());
      bool b;
      stream >> b;
      return b & 1;  // make sure it's actually just 0 or 1
    }
    static int tokenizeToStr(const char * str, std::vector<std::string> & items, 
                                const char * delm = "\t") {
      char * buff = const_cast<char *>(str);
      int initSize = items.size();
      char * pch = strtok(buff, delm);
      while( pch != NULL ) {
        items.push_back(pch);
        pch = strtok(NULL, delm);
      }
      return items.size() - initSize;
    }
    static int tokenizeToStr(std::string buff, std::vector<std::string> & items, 
                                std::string delm = "\t") {
      return tokenizeToStr(buff.c_str(), items, delm.c_str());
    }
    static int tokenizeToInt(std::string buff, std::vector<uint32_t> & items, 
                                std::string delm = ",") {
      std::vector<std::string> tmpVector(0);
      int i = 0;
      i = tokenizeToStr(buff.c_str(), tmpVector, delm.c_str());
      if( i > 0 ) {
        for( int j = 0; j < i; j++ ) {
          printf("%s\n", tmpVector[j].c_str()); 
          items.push_back(atoi(tmpVector[j].c_str()));
          printf("%d\n", items[j]); 
        }
      }
      return i;
    }
    static void trim(std::string & str, const std::string dropChars = " \t\n\r") {
      str.erase(str.find_last_not_of(dropChars)+1);
      str.erase(0, str.find_first_not_of(dropChars));
    }

    static float Round(double n, int precision){
      return floor(n * pow(10., precision) + .5) / pow(10., precision);
    }

  };
}  // ends namespace

#endif  // INC_RANDLM_UTILS_H
