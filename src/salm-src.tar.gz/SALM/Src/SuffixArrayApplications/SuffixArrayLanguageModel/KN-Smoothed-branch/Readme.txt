June 27, 2007

Working branch of applying KN smoothing in LM.
Not finished yet.
Do not distribute!