List of the files included in this package:
./mteval-v13a.pl : version 13a of the evaluation script. The history section
describes the changes that were introduced for each new release.
./example/ref.xml : sample reference file
./example/src.xml : sample source file
./example/tst.xml : sample test file
./example/run_B.txt : output generated when using '-b' option (BLEU score only)
./example/run_C.txt : output generated when using '-c' option (case-sensitivity)
./example/run_D3.txt : output generated when using '-d 3' option (detailed output)
./example/run_N.txt : output generated when using '-n' option (NIST score only)
./example/run_NOARG.txt : output generated when using default options

To display all possible command line options:
./mteval-v13a.pl -h

Any questions and/or comments may be addressed to: mt_poc@nist.gov
